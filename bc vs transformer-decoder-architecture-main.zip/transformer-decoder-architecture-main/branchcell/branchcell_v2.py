"""
BranchCell v2 — Token-level causal architecture with gated linear branch memory.

Key upgrades over v1 (the version in the original experiment):
  1. NO mean-pooling before processing. Every token is processed in sequence.
     (v1 collapsed the whole sequence with e.mean(dim=1) -> it was a bag-of-words MLP.)
  2. Real recurrent memory: each branch keeps a state MATRIX S (dk x dv) updated
     causally per token with learned per-token forget gates (data-dependent decay):
         S_t = g_t * S_{t-1} + k_t (outer) v_t
         o_t = q_t . S_t
     This is O(n) in sequence length and O(1) memory at inference,
     vs O(n^2) attention in a decoder-only Transformer.
  3. Memory is PER-SAMPLE and reset every forward pass.
     (v1 leaked hidden state across unrelated batches via persistent buffers.)
  4. The signature "triple fusion" (linear + interactive + competitive) is kept,
     but applied across branches PER TOKEN instead of on a pooled vector.
  5. Stochastic reparameterization noise removed (it only added seed variance).
  6. Proper deep residual stack: RMSNorm -> BranchMemory -> residual,
     RMSNorm -> SwiGLU MLP -> residual.
  7. Causal readout from the last non-pad token (no positional info lost).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return self.w * x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)


class BranchMemory(nn.Module):
    """Parallel branches, each with a gated linear recurrent state matrix.

    Shapes: x (B, T, d) -> out (B, T, d). Causal, O(T) time, O(1) state.
    """

    def __init__(self, d, n_branch=4, dk=32, dv=32, chunk=32):
        super().__init__()
        self.nb, self.dk, self.dv, self.chunk = n_branch, dk, dv, chunk
        self.Wq = nn.Linear(d, n_branch * dk, bias=False)
        self.Wk = nn.Linear(d, n_branch * dk, bias=False)
        self.Wv = nn.Linear(d, n_branch * dv, bias=False)
        # data-dependent forget gate (decay) per branch per key-dim
        self.Wg = nn.Linear(d, n_branch * dk, bias=True)
        nn.init.constant_(self.Wg.bias, 4.0)  # start with long memory
        # --- signature triple fusion across branches ---
        self.beta = nn.Parameter(torch.zeros(n_branch))           # linear mix
        self.gamma = nn.Parameter(torch.tensor(0.1))              # interactive
        self.zeta = nn.Parameter(torch.tensor(0.2))               # competitive
        self.out = nn.Linear(dv, d, bias=False)

    def forward(self, x):
        """Chunkwise-parallel scan of the gated linear recurrence:
            S_t = diag(g_t) S_{t-1} + k_t v_t^T ;  o_t = q_t^T S_t
        Computed exactly, in parallel within chunks of length C, with the
        recurrent state carried across chunks. O(T) time, O(1) state.
        """
        B, T, _ = x.shape
        nb, dk, dv, C = self.nb, self.dk, self.dv, self.chunk
        q = F.silu(self.Wq(x)).view(B, T, nb, dk)
        k = F.silu(self.Wk(x)).view(B, T, nb, dk)
        v = self.Wv(x).view(B, T, nb, dv)
        # gate in [0.5, 1.0] for numerical stability of the chunkwise form
        g = 0.5 + 0.5 * torch.sigmoid(self.Wg(x)).view(B, T, nb, dk)

        # pad T to a multiple of C (pads have k from zero-embeddings -> silu(0)=0,
        # so they contribute nothing; readout ignores them anyway)
        pad = (C - T % C) % C
        if pad:
            q = F.pad(q, (0, 0, 0, 0, 0, pad)); k = F.pad(k, (0, 0, 0, 0, 0, pad))
            v = F.pad(v, (0, 0, 0, 0, 0, pad))
            g = F.pad(g, (0, 0, 0, 0, 0, pad), value=1.0)
        Tp = T + pad
        nC = Tp // C
        q = q.view(B, nC, C, nb, dk); k = k.view(B, nC, C, nb, dk)
        v = v.view(B, nC, C, nb, dv); g = g.view(B, nC, C, nb, dk)

        lg = torch.log(g)
        A = torch.cumsum(lg, dim=2)              # decay from chunk start to t (incl.)
        eA = torch.exp(A)                        # (B,nC,C,nb,dk)
        eA_last = eA[:, :, -1]                   # total chunk decay
        q_dec = q * eA                           # q_t * D_t
        k_dec = k / eA                           # k_s / D_s  (bounded: g >= 0.5, C small)
        k_rem = k * torch.exp(A[:, :, -1:] - A)  # k_s * D_C/D_s (for state update)

        mask = torch.tril(torch.ones(C, C, device=x.device, dtype=torch.bool))
        S = x.new_zeros(B, nb, dk, dv)           # per-sample state, fresh every forward
        outs = []
        for c in range(nC):
            # inter-chunk: contribution of carried state
            o_inter = torch.einsum('bcnk,bnkv->bcnv', q_dec[:, c], S)
            # intra-chunk: exact causal pairwise within the chunk
            scores = torch.einsum('bcnk,bdnk->bncd', q_dec[:, c], k_dec[:, c])
            scores = scores.masked_fill(~mask, 0.0)
            o_intra = torch.einsum('bncd,bdnv->bcnv', scores, v[:, c])
            outs.append(o_inter + o_intra)
            # carry state: S <- D_C * S + sum_s (D_C/D_s) k_s v_s^T
            S = eA_last[:, c].unsqueeze(-1) * S + torch.einsum(
                'bcnk,bcnv->bnkv', k_rem[:, c], v[:, c])
        Z = torch.cat(outs, dim=1)[:, :T]        # (B, T, nb, dv)

        # triple fusion across branches, per token
        w = F.softmax(self.beta, dim=0)
        lin = torch.einsum('n,btnd->btd', w, Z)
        zs = Z.sum(dim=2)
        inter = self.gamma * ((zs ** 2) - (Z ** 2).sum(dim=2)) / 2
        comp = self.zeta * Z.max(dim=2)[0]
        fused = lin + inter + comp
        return self.out(fused)


class SwiGLU(nn.Module):
    def __init__(self, d, mult=2):
        super().__init__()
        h = d * mult
        self.w1 = nn.Linear(d, h, bias=False)
        self.w2 = nn.Linear(d, h, bias=False)
        self.w3 = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


class BranchCellV2(nn.Module):
    """Causal classifier / LM backbone built from BranchMemory blocks."""

    def __init__(self, vocab, d=128, n_layers=2, n_branch=4, dk=32, dv=32,
                 n_classes=3, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList()
        for _ in range(n_layers):
            self.blocks.append(nn.ModuleDict({
                'n1': RMSNorm(d),
                'mem': BranchMemory(d, n_branch, dk, dv),
                'n2': RMSNorm(d),
                'mlp': SwiGLU(d),
            }))
        self.norm_f = RMSNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        pad_mask = (x != 0)
        h = self.drop(self.emb(x))
        for blk in self.blocks:
            h = h + blk['mem'](blk['n1'](h))
            h = h + blk['mlp'](blk['n2'](h))
        h = self.norm_f(h)
        # read the LAST non-pad token (causal readout — all context flowed into it)
        lengths = pad_mask.long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(x.size(0), device=x.device), lengths]
        return self.head(last)


class DecoderTransformer(nn.Module):
    """Fair baseline: causal decoder-only Transformer (the modern-AI standard)."""

    def __init__(self, vocab, d=128, n_layers=2, n_heads=4, n_classes=3,
                 max_len=1024, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.pe = nn.Embedding(max_len, d)
        layer = nn.TransformerEncoderLayer(d, n_heads, d * 3, dropout, 'gelu',
                                           batch_first=True, norm_first=True)
        self.trf = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        B, T = x.shape
        pad_mask = (x == 0)
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        h = self.emb(x) + self.pe(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.trf(h, mask=causal, src_key_padding_mask=pad_mask)
        h = self.norm(h)
        lengths = (~pad_mask).long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(B, device=x.device), lengths]
        return self.head(last)
