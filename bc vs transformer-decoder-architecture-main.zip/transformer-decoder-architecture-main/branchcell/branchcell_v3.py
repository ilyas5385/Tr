"""
BranchCell v3 — Hard-Routed Gated Linear Branch Memory.

This is the final architecture. It keeps the BranchCell identity (parallel
branches + gates + triple fusion) but adds two decisive upgrades:

  (A) HARD ROUTING of memory writes (Mixture-of-Experts style).
      A per-token router scores the branches and selects the top-k.
      Only the selected branches WRITE to their recurrent state at that token:
          r_t   = top_k_softmax(router(x_t))            # sparse weights, sum=1
          S_n   = g_n ⊙ S_n  +  r_{t,n} · (k_n ⊗ v_n)   # write only if routed
          o_n   = q_n^T S_n                              # cheap readout
      => branches SPECIALIZE: each becomes an expert over a token sub-population.
         Capacity grows with n_branch while write-cost stays ~k (not n_branch).

  (B) Improvements over v2:
      - Multi-head readout query per branch (better recall per state cell).
      - Short causal depthwise conv before the recurrence (local n-gram features,
        the "Based/Hyena" trick that fixes most of the linear-attention quality gap).
      - Load-balancing auxiliary loss so the router uses all branches.
      - Output gating (GLA-style) for sharper, more selective memory readout.

Complexity: O(T) time, O(1) state at inference, vs O(T^2) for softmax attention.
All operations are causal (verified by test_v3.py).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return self.w * x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)


class HardRoutedBranchMemory(nn.Module):
    """Parallel branches with gated linear recurrent memory and HARD top-k
    routing of memory writes.

    x (B, T, d) -> (out (B, T, d), aux_load_balance_loss)
    """

    def __init__(self, d, n_branch=8, top_k=2, dk=24, dv=24, conv_k=3):
        super().__init__()
        assert 1 <= top_k <= n_branch
        self.nb, self.k, self.dk, self.dv = n_branch, top_k, dk, dv
        self.Wq = nn.Linear(d, n_branch * dk, bias=False)
        self.Wk = nn.Linear(d, n_branch * dk, bias=False)
        self.Wv = nn.Linear(d, n_branch * dv, bias=False)
        # data-dependent forget gate (per branch, per key-dim)
        self.Wg = nn.Linear(d, n_branch * dk, bias=True)
        nn.init.constant_(self.Wg.bias, 4.0)  # sigmoid(4)≈0.982 -> long memory start
        # output gate (GLA-style selective readout)
        self.Wog = nn.Linear(d, n_branch * dv, bias=True)
        # token router over branches (the hard-routing brain)
        self.router = nn.Linear(d, n_branch, bias=False)
        # short causal depthwise conv for local n-gram features
        self.conv_k = conv_k
        self.conv = nn.Conv1d(d, d, conv_k, groups=d, padding=0, bias=True)
        # signature triple fusion across branches
        self.gamma = nn.Parameter(torch.tensor(0.1))   # interactive
        self.zeta = nn.Parameter(torch.tensor(0.2))    # competitive
        self.out = nn.Linear(dv, d, bias=False)

    def _route(self, x):
        """Top-k hard routing. Returns sparse weights r (B,T,nb) and aux loss."""
        logits = self.router(x)                       # (B,T,nb)
        probs = F.softmax(logits, dim=-1)
        topv, topi = probs.topk(self.k, dim=-1)       # (B,T,k)
        topv = topv / (topv.sum(-1, keepdim=True) + 1e-9)
        r = torch.zeros_like(probs).scatter_(-1, topi, topv)  # hard, sparse
        # Switch-Transformer load-balancing aux loss
        importance = probs.mean(dim=(0, 1))                       # soft usage
        sel = torch.zeros_like(probs).scatter_(-1, topi, 1.0)
        load = sel.mean(dim=(0, 1))                               # hard usage
        aux = self.nb * (importance * load).sum()
        return r, aux

    def forward(self, x):
        B, T, d = x.shape
        nb, dk, dv = self.nb, self.dk, self.dv

        # local causal conv (left-pad so position t only sees <= t)
        xc = F.pad(x.transpose(1, 2), (self.conv_k - 1, 0))
        xc = self.conv(xc).transpose(1, 2)
        xl = x + F.silu(xc)                                 # fuse local features

        q = F.silu(self.Wq(xl)).view(B, T, nb, dk)
        k = F.silu(self.Wk(xl)).view(B, T, nb, dk)
        v = self.Wv(xl).view(B, T, nb, dv)
        g = torch.sigmoid(self.Wg(xl)).view(B, T, nb, dk)
        og = torch.sigmoid(self.Wog(xl)).view(B, T, nb, dv)
        r, aux = self._route(xl)                            # (B,T,nb)

        # gated linear recurrence with HARD-routed writes (sequential, O(T))
        S = x.new_zeros(B, nb, dk, dv)
        outs = []
        for t in range(T):
            write = r[:, t].unsqueeze(-1).unsqueeze(-1)     # (B,nb,1,1)
            kv = k[:, t].unsqueeze(-1) * v[:, t].unsqueeze(-2)
            S = g[:, t].unsqueeze(-1) * S + write * kv
            o_t = torch.einsum('bnk,bnkv->bnv', q[:, t], S)
            outs.append(o_t)
        Z = torch.stack(outs, dim=1) * og                  # (B,T,nb,dv), output-gated

        # triple fusion across branches, per token, weighted by routing
        lin = torch.einsum('btn,btnv->btv', r, Z)          # route-weighted linear mix
        zr = Z * r.unsqueeze(-1)                            # mask to active branches
        zs = zr.sum(dim=2)
        inter = self.gamma * ((zs ** 2) - (zr ** 2).sum(dim=2)) / 2
        comp = self.zeta * Z.max(dim=2)[0]
        fused = lin + inter + comp
        return self.out(fused), aux


class SwiGLU(nn.Module):
    def __init__(self, d, mult=2):
        super().__init__()
        h = d * mult
        self.w1 = nn.Linear(d, h, bias=False)
        self.w2 = nn.Linear(d, h, bias=False)
        self.w3 = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


class BranchCellV3(nn.Module):
    """Causal classifier backbone built from hard-routed branch-memory blocks."""

    def __init__(self, vocab, d=128, n_layers=2, n_branch=8, top_k=2,
                 dk=24, dv=24, n_classes=3, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList()
        for _ in range(n_layers):
            self.blocks.append(nn.ModuleDict({
                'n1': RMSNorm(d),
                'mem': HardRoutedBranchMemory(d, n_branch, top_k, dk, dv),
                'n2': RMSNorm(d),
                'mlp': SwiGLU(d),
            }))
        self.norm_f = RMSNorm(d)
        self.head = nn.Linear(d, n_classes)
        self.aux_coef = 0.01

    def forward(self, x, return_aux=False):
        pad_mask = (x != 0)
        h = self.drop(self.emb(x))
        total_aux = h.new_zeros(())
        for blk in self.blocks:
            mem_out, aux = blk['mem'](blk['n1'](h))
            h = h + mem_out
            total_aux = total_aux + aux
            h = h + blk['mlp'](blk['n2'](h))
        h = self.norm_f(h)
        lengths = pad_mask.long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(x.size(0), device=x.device), lengths]
        logits = self.head(last)
        if return_aux:
            return logits, self.aux_coef * total_aux / len(self.blocks)
        return logits


class DecoderTransformer(nn.Module):
    """Fair baseline: causal decoder-only Transformer (the modern-AI standard)."""

    def __init__(self, vocab, d=128, n_layers=2, n_heads=4, n_classes=3,
                 max_len=2048, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.pe = nn.Embedding(max_len, d)
        layer = nn.TransformerEncoderLayer(d, n_heads, d * 3, dropout, 'gelu',
                                           batch_first=True, norm_first=True)
        self.trf = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        B, T = x.shape
        pad_mask = (x == 0)
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        h = self.emb(x) + self.pe(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.trf(h, mask=causal, src_key_padding_mask=pad_mask)
        h = self.norm(h)
        lengths = (~pad_mask).long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(B, device=x.device), lengths]
        return self.head(last)
