"""
BranchCell v4 — Hybrid Multi-Scale Branch Memory with RoPE & Local Attention.

This is the CONVERGENCE architecture. It keeps v3's hard-routed branch memory
but adds the MISSING PIECES that prevented v2/v3 from beating Transformer:

  (A) Rotary Positional Embedding (RoPE) on ALL Q, K, V projections.
      Without PE, the model is BLIND to token position → Needle tasks fail.
      RoPE gives relative position awareness naturally.

  (B) MULTI-SCALE memory per branch (not just one S matrix):
      - Fast scale:  high decay  → remembers only recent tokens (local)
      - Slow scale:  low decay   → remembers old tokens (long-range)
      - Medium:      balanced    → the sweet spot
      Each scale captures different temporal frequencies. This is the KEY
      insight: a single memory matrix cannot simultaneously remember
      yesterday AND last year. Multiple scales = multiple "time resolutions".

  (C) Local short attention window (sliding, causal).
      The pure recurrent form loses fine-grained short-range detail.
      A small sliding attention (window=32) fixes this — it is still O(T)
      because each token only attends to at most 32 previous ones.

  (D) Adaptive fusion gate (learned) between:
      - local attention output (fine detail, short range)
      - multi-scale branch memory (coarse, long range)
      The network learns WHEN to use WHICH.

  (E) Retained from v3 (proven):
      - Hard top-k routing of memory writes
      - Depthwise causal conv for local n-gram features
      - Triple fusion (linear + interactive + competitive)
      - Output gating (GLA-style)
      - Load-balancing aux loss

Complexity: O(T) time (windowed attention is O(T*w)), O(1) state at inference.
vs Transformer O(T^2) attention.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return self.w * x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)


def apply_rope(qk, positions):
    """Apply Rotary Positional Embedding to q or k (B, T, nb, dk).
    positions: (T,) precomputed angles.
    """
    B, T, nb, dk = qk.shape
    if dk % 2 != 0:
        # odd dk: pad, apply, unpad
        qk_padded = F.pad(qk, (0, 1))  # (B,T,nb,dk+1)
        out = apply_rope(qk_padded, positions)
        return out[..., :dk]
    
    dim_idx = torch.arange(0, dk, 2, device=qk.device).float()
    inv_freq = 1.0 / (10000 ** (dim_idx / dk))  # (dk/2,)
    
    # positions: (T,)
    angles = torch.outer(positions, inv_freq)  # (T, dk/2)
    cos = torch.cos(angles)  # (T, dk/2)
    sin = torch.sin(angles)  # (T, dk/2)
    
    # reshape qk: (B, T, nb, dk/2, 2)
    qk_reshaped = qk.reshape(B, T, nb, dk // 2, 2)
    q_real, q_imag = qk_reshaped[..., 0], qk_reshaped[..., 1]  # each (B,T,nb,dk/2)
    
    # apply rotation: (a+bi)(cos+isin) = (a*cos - b*sin) + (a*sin + b*cos)i
    out_real = q_real * cos.unsqueeze(1) - q_imag * sin.unsqueeze(1)   # (B,T,nb,dk/2)
    out_imag = q_real * sin.unsqueeze(1) + q_imag * cos.unsqueeze(1)
    
    out = torch.stack([out_real, out_imag], dim=-1)  # (B,T,nb,dk/2,2)
    return out.reshape(B, T, nb, dk)


class MultiScaleHardRoutedBranchMemory(nn.Module):
    """Hard-routed branch memory with MULTI-SCALE recurrent states + RoPE + local attention.

    x (B, T, d) -> (out (B, T, d), aux_load_balance_loss)
    """

    def __init__(self, d, n_branch=8, top_k=2, dk=24, dv=24, conv_k=4,
                 n_scales=3, local_win=32):
        super().__init__()
        assert 1 <= top_k <= n_branch
        self.nb, self.k, self.dk, self.dv = n_branch, top_k, dk, dv
        self.n_scales = n_scales
        self.local_win = local_win

        # projections (shared, then RoPE-d)
        self.Wq = nn.Linear(d, n_branch * dk, bias=False)
        self.Wk = nn.Linear(d, n_branch * dk, bias=False)
        self.Wv = nn.Linear(d, n_branch * dv, bias=False)

        # data-dependent forget gate PER SCALE → each scale learns its own decay
        self.Wg = nn.ModuleList([
            nn.Linear(d, n_branch * dk, bias=True) for _ in range(n_scales)
        ])
        # Initialize with DIFFERENT biases so scales specialize naturally
        init_biases = [2.0, 4.0, 6.0]  # fast→medium→slow memory
        for i, wg in enumerate(self.Wg):
            nn.init.constant_(wg.bias, init_biases[min(i, len(init_biases)-1)])

        # output gate (GLA-style)
        self.Wog = nn.Linear(d, n_branch * dv, bias=True)

        # token router
        self.router = nn.Linear(d, n_branch, bias=False)

        # causal depthwise conv for local n-gram features
        self.conv_k = conv_k
        self.conv = nn.Conv1d(d, d, conv_k, groups=d, padding=0, bias=True)

        # LOCAL SLIDING ATTENTION (causal, windowed)
        if local_win > 0:
            self.local_q = nn.Linear(d, n_branch * dk // 2, bias=False)
            self.local_k = nn.Linear(d, n_branch * dk // 2, bias=False)
            self.local_v = nn.Linear(d, n_branch * dv, bias=False)
            self.local_out = nn.Linear(n_branch * dv, d, bias=False)

        # scale fusion: learned combination of scales
        self.scale_gates = nn.Parameter(torch.ones(n_scales) / n_scales)

        # signature triple fusion
        self.gamma = nn.Parameter(torch.tensor(0.1))
        self.zeta = nn.Parameter(torch.tensor(0.2))

        # adaptive fusion: local attn vs branch memory
        self.fusion_gate = nn.Linear(d * 2, 1, bias=True)

        self.out = nn.Linear(dv, d, bias=False)

    def _route(self, x):
        """Top-k hard routing."""
        logits = self.router(x)
        probs = F.softmax(logits, dim=-1)
        topv, topi = probs.topk(self.k, dim=-1)
        topv = topv / (topv.sum(-1, keepdim=True) + 1e-9)
        r = torch.zeros_like(probs).scatter_(-1, topi, topv)
        importance = probs.mean(dim=(0, 1))
        sel = torch.zeros_like(probs).scatter_(-1, topi, 1.0)
        load = sel.mean(dim=(0, 1))
        aux = self.nb * (importance * load).sum()
        return r, aux

    def _local_sliding_attention(self, x):
        """Causal sliding window attention. O(T * win) per token."""
        B, T, d = x.shape
        nb, dk_half, dv = self.nb, self.dk // 2, self.dv
        
        q = self.local_q(x).view(B, T, nb, dk_half)
        k = self.local_k(x).view(B, T, nb, dk_half)
        v = self.local_v(x).view(B, T, nb, dv)

        # RoPE on local q, k
        positions = torch.arange(T, device=x.device, dtype=torch.float32)
        q = apply_rope(q, positions)
        k = apply_rope(k, positions)

        outputs = []
        for t in range(T):
            win_start = max(0, t - self.local_win + 1)
            q_t = q[:, t]  # (B, nb, dk_half)
            k_win = k[:, win_start:t+1]  # (B, win, nb, dk_half)
            v_win = v[:, win_start:t+1]  # (B, win, nb, dv)
            
            # scores: (B, nb, win)
            scores = torch.einsum('bnk,bwnk->bnw', q_t, k_win)
            scores = scores / math.sqrt(dk_half)
            probs = F.softmax(scores, dim=-1)  # (B, nb, win)
            
            # weighted sum
            out_t = torch.einsum('bnw,bwnv->bnv', probs, v_win)  # (B, nb, dv)
            outputs.append(out_t)
        
        Z_local = torch.stack(outputs, dim=1)  # (B, T, nb, dv)
        # flatten branches
        Z_local = Z_local.reshape(B, T, nb * dv)
        return self.local_out(Z_local)  # (B, T, d)

    def forward(self, x):
        B, T, d = x.shape
        nb, dk, dv = self.nb, self.dk, self.dv

        # local causal conv
        xc = F.pad(x.transpose(1, 2), (self.conv_k - 1, 0))
        xc = self.conv(xc).transpose(1, 2)
        xl = x + F.silu(xc)

        # projections
        q = F.silu(self.Wq(xl)).view(B, T, nb, dk)
        k = F.silu(self.Wk(xl)).view(B, T, nb, dk)
        v = self.Wv(xl).view(B, T, nb, dv)

        # RoPE on q and k
        positions = torch.arange(T, device=x.device, dtype=torch.float32)
        q = apply_rope(q, positions)
        k = apply_rope(k, positions)

        og = torch.sigmoid(self.Wog(xl)).view(B, T, nb, dv)
        r, aux = self._route(xl)

        # Multi-scale gated linear recurrence
        # Each scale has its own S and its own gate
        S_list = [x.new_zeros(B, nb, dk, dv) for _ in range(self.n_scales)]
        scale_outputs = [[] for _ in range(self.n_scales)]

        for t in range(T):
            for s in range(self.n_scales):
                g = torch.sigmoid(self.Wg[s](xl[:, t])).view(B, nb, dk)
                # Different scales = different effective memory lengths
                # Higher bias -> higher gate -> longer memory
                write = r[:, t].unsqueeze(-1).unsqueeze(-1)
                kv = k[:, t].unsqueeze(-1) * v[:, t].unsqueeze(-2)
                S_list[s] = g.unsqueeze(-1) * S_list[s] + write * kv
                o_t = torch.einsum('bnk,bnkv->bnv', q[:, t], S_list[s])
                scale_outputs[s].append(o_t)

        # Stack each scale
        Z_scales = []
        for s in range(self.n_scales):
            Z_s = torch.stack(scale_outputs[s], dim=1) * og  # (B,T,nb,dv)
            Z_scales.append(Z_s)

        # Scale fusion: learned weighted combination
        scale_weights = F.softmax(self.scale_gates, dim=0)
        Z = sum(scale_weights[s] * Z_scales[s] for s in range(self.n_scales))

        # triple fusion across branches
        lin = torch.einsum('btn,btnv->btv', r, Z)
        zr = Z * r.unsqueeze(-1)
        zs = zr.sum(dim=2)
        inter = self.gamma * ((zs ** 2) - (zr ** 2).sum(dim=2)) / 2
        comp = self.zeta * Z.max(dim=2)[0]
        fused_branch = lin + inter + comp
        out_branch = self.out(fused_branch)  # (B, T, d)

        # Local sliding attention
        if self.local_win > 0:
            out_local = self._local_sliding_attention(xl)
            # Adaptive fusion gate
            fusion_input = torch.cat([out_branch, out_local], dim=-1)  # (B,T,2d)
            gate = torch.sigmoid(self.fusion_gate(fusion_input))  # (B,T,1)
            out = gate * out_branch + (1 - gate) * out_local
        else:
            out = out_branch

        return out, aux


class SwiGLU(nn.Module):
    def __init__(self, d, mult=2):
        super().__init__()
        h = d * mult
        self.w1 = nn.Linear(d, h, bias=False)
        self.w2 = nn.Linear(d, h, bias=False)
        self.w3 = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


class BranchCellV4(nn.Module):
    """Causal classifier backbone: Multi-Scale Hard-Routed Branch Memory + RoPE + Local Attention."""

    def __init__(self, vocab, d=128, n_layers=2, n_branch=8, top_k=2,
                 dk=24, dv=24, n_classes=3, dropout=0.1,
                 n_scales=3, local_win=32):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList()
        for _ in range(n_layers):
            self.blocks.append(nn.ModuleDict({
                'n1': RMSNorm(d),
                'mem': MultiScaleHardRoutedBranchMemory(
                    d, n_branch, top_k, dk, dv,
                    n_scales=n_scales, local_win=local_win),
                'n2': RMSNorm(d),
                'mlp': SwiGLU(d),
            }))
        self.norm_f = RMSNorm(d)
        self.head = nn.Linear(d, n_classes)
        self.aux_coef = 0.01

    def forward(self, x, return_aux=False):
        pad_mask = (x != 0)
        h = self.drop(self.emb(x))
        total_aux = h.new_zeros(())
        for blk in self.blocks:
            mem_out, aux = blk['mem'](blk['n1'](h))
            h = h + mem_out
            total_aux = total_aux + aux
            h = h + blk['mlp'](blk['n2'](h))
        h = self.norm_f(h)
        lengths = pad_mask.long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(x.size(0), device=x.device), lengths]
        logits = self.head(last)
        if return_aux:
            return logits, self.aux_coef * total_aux / len(self.blocks)
        return logits


class DecoderTransformer(nn.Module):
    """Fair baseline: causal decoder-only Transformer (the modern-AI standard)."""

    def __init__(self, vocab, d=128, n_layers=2, n_heads=4, n_classes=3,
                 max_len=2048, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.pe = nn.Embedding(max_len, d)
        layer = nn.TransformerEncoderLayer(d, n_heads, d * 3, dropout, 'gelu',
                                           batch_first=True, norm_first=True)
        self.trf = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        B, T = x.shape
        pad_mask = (x == 0)
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        h = self.emb(x) + self.pe(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.trf(h, mask=causal, src_key_padding_mask=pad_mask)
        h = self.norm(h)
        lengths = (~pad_mask).long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(B, device=x.device), lengths]
        return self.head(last)
