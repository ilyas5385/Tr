"""
BranchCell v4b — Refined Hybrid Multi-Scale Branch Memory.

Changes from v4:
  1. SIMPLER multi-scale: shared K,V projections, different gates only.
     (v4 had separate Wg per scale -> too many params for small models.)
  2. Larger local window (32 default) for better short-range recall.
  3. RoPE applied to q,k of BOTH branch memory AND local attention.
  4. Gating range expanded: sigmoid(bias) gives [0.018, 0.998] range
     (v2 limited to [0.5,1.0] which prevented fast forgetting.)
  5. Top-k routing uses k=nb//2 instead of fixed k=2.
  6. Conv kernel increased to 4 for better local n-gram capture.
  7. Added learnable positional bias (fallback if RoPE insufficient).

The key insight: v4's multi-scale was too heavy. This version keeps the
same IDEAS (RoPE + multi-scale + local attn) but implements them more
efficiently so small models can actually benefit.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return self.w * x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)


def apply_rope(qk, positions):
    """Apply Rotary Positional Embedding. qk: (B, T, H, D), positions: (T,)"""
    B, T, H, D = qk.shape
    if D % 2 != 0:
        qk_padded = F.pad(qk, (0, 1))
        out = apply_rope(qk_padded, positions)
        return out[..., :D]
    dim_idx = torch.arange(0, D, 2, device=qk.device).float()
    inv_freq = 1.0 / (10000 ** (dim_idx / D))
    angles = torch.outer(positions.float(), inv_freq)
    cos, sin = torch.cos(angles), torch.sin(angles)
    qk_r = qk.reshape(B, T, H, D // 2, 2)
    real, imag = qk_r[..., 0], qk_r[..., 1]
    out_r = real * cos.unsqueeze(1) - imag * sin.unsqueeze(1)
    out_i = real * sin.unsqueeze(1) + imag * cos.unsqueeze(1)
    return torch.stack([out_r, out_i], dim=-1).reshape(B, T, H, D)


class EfficientMultiScaleBranchMemory(nn.Module):
    def __init__(self, d, n_branch=8, top_k=None, dk=24, dv=24, conv_k=4,
                 n_scales=3, local_win=32):
        super().__init__()
        self.nb = n_branch
        self.k = top_k if top_k is not None else max(1, n_branch // 2)
        self.dk, self.dv = dk, dv
        self.n_scales = n_scales
        self.local_win = local_win

        # Shared projections
        self.Wq = nn.Linear(d, n_branch * dk, bias=False)
        self.Wk = nn.Linear(d, n_branch * dk, bias=False)
        self.Wv = nn.Linear(d, n_branch * dv, bias=False)

        # ONE gate module, different scales via different bias terms
        self.Wg = nn.Linear(d, n_scales * n_branch * dk, bias=True)
        # Initialize biases so each scale gets a different decay rate
        scale_biases = torch.linspace(1.0, 5.0, n_scales)  # [1, 3, 5] for 3 scales
        for i in range(n_scales):
            nn.init.constant_(self.Wg.bias.view(n_scales, n_branch * dk)[i], scale_biases[i])

        self.Wog = nn.Linear(d, n_branch * dv, bias=True)
        self.router = nn.Linear(d, n_branch, bias=False)

        # Causal depthwise conv
        self.conv_k = conv_k
        self.conv = nn.Conv1d(d, d, conv_k, groups=d, padding=0, bias=True)

        # Local sliding attention
        if local_win > 0:
            self.local_q = nn.Linear(d, n_branch * dk // 2, bias=False)
            self.local_k = nn.Linear(d, n_branch * dk // 2, bias=False)
            self.local_v = nn.Linear(d, n_branch * dv, bias=False)
            self.local_out = nn.Linear(n_branch * dv, d, bias=False)

        # Scale combination weights
        self.scale_gates = nn.Parameter(torch.ones(n_scales))

        # Triple fusion
        self.gamma = nn.Parameter(torch.tensor(0.1))
        self.zeta = nn.Parameter(torch.tensor(0.2))

        # Adaptive fusion
        self.fusion_gate = nn.Linear(d * 2, 1, bias=True)

        self.out = nn.Linear(dv, d, bias=False)

        # Learnable positional bias (supplement to RoPE)
        self.pos_bias = nn.Parameter(torch.zeros(1, 1, n_branch, dk))

    def _route(self, x):
        logits = self.router(x)
        probs = F.softmax(logits, dim=-1)
        topv, topi = probs.topk(self.k, dim=-1)
        topv = topv / (topv.sum(-1, keepdim=True) + 1e-9)
        r = torch.zeros_like(probs).scatter_(-1, topi, topv)
        importance = probs.mean(dim=(0, 1))
        sel = torch.zeros_like(probs).scatter_(-1, topi, 1.0)
        load = sel.mean(dim=(0, 1))
        aux = self.nb * (importance * load).sum()
        return r, aux

    def _local_sliding_attention(self, x):
        B, T, d = x.shape
        nb, dk_h, dv = self.nb, self.dk // 2, self.dv
        q = self.local_q(x).view(B, T, nb, dk_h)
        k = self.local_k(x).view(B, T, nb, dk_h)
        v = self.local_v(x).view(B, T, nb, dv)

        positions = torch.arange(T, device=x.device, dtype=torch.float32)
        q = apply_rope(q, positions)
        k = apply_rope(k, positions)

        outputs = []
        for t in range(min(T, 512)):  # cap for speed
            ws = max(0, t - self.local_win + 1)
            q_t = q[:, t]
            k_w = k[:, ws:t+1]
            v_w = v[:, ws:t+1]
            scores = torch.einsum('bnk,bwnk->bnw', q_t, k_w) / math.sqrt(dk_h)
            probs = F.softmax(scores, dim=-1)
            out_t = torch.einsum('bnw,bwnv->bnv', probs, v_w)
            outputs.append(out_t)

        Z = torch.stack(outputs, dim=1) if outputs else x.new_zeros(B, T, nb, dv)
        Z = Z.reshape(B, T, nb * dv)
        return self.local_out(Z)

    def forward(self, x):
        B, T, d = x.shape
        nb, dk, dv = self.nb, self.dk, self.dv

        # Causal conv
        xc = F.pad(x.transpose(1, 2), (self.conv_k - 1, 0))
        xc = self.conv(xc).transpose(1, 2)
        xl = x + F.silu(xc)

        # Projections
        q = F.silu(self.Wq(xl)).view(B, T, nb, dk)
        k = F.silu(self.Wk(xl)).view(B, T, nb, dk)
        v = self.Wv(xl).view(B, T, nb, dv)

        # RoPE
        positions = torch.arange(T, device=x.device, dtype=torch.float32)
        q = apply_rope(q, positions)
        k = apply_rope(k, positions)

        # Add learnable positional bias
        q = q + self.pos_bias

        og = torch.sigmoid(self.Wog(xl)).view(B, T, nb, dv)
        r, aux = self._route(xl)

        # Multi-scale: one forward, different gate values per scale
        g_all = torch.sigmoid(self.Wg(xl)).view(B, T, self.n_scales, nb, dk)

        S_list = [x.new_zeros(B, nb, dk, dv) for _ in range(self.n_scales)]
        scale_outputs = [[] for _ in range(self.n_scales)]

        for t in range(T):
            write = r[:, t].unsqueeze(-1).unsqueeze(-1)
            kv = k[:, t].unsqueeze(-1) * v[:, t].unsqueeze(-2)
            for s in range(self.n_scales):
                g = g_all[:, t, s]
                S_list[s] = g.unsqueeze(-1) * S_list[s] + write * kv
                o_t = torch.einsum('bnk,bnkv->bnv', q[:, t], S_list[s])
                scale_outputs[s].append(o_t)

        Z_scales = [torch.stack(so, dim=1) * og for so in scale_outputs]
        sw = F.softmax(self.scale_gates, dim=0)
        Z = sum(sw[s] * Z_scales[s] for s in range(self.n_scales))

        # Triple fusion
        lin = torch.einsum('btn,btnv->btv', r, Z)
        zr = Z * r.unsqueeze(-1)
        zs = zr.sum(dim=2)
        inter = self.gamma * ((zs ** 2) - (zr ** 2).sum(dim=2)) / 2
        comp = self.zeta * Z.max(dim=2)[0]
        fused_branch = lin + inter + comp
        out_branch = self.out(fused_branch)

        if self.local_win > 0 and T <= 512:
            out_local = self._local_sliding_attention(xl)
            fg = torch.sigmoid(self.fusion_gate(torch.cat([out_branch, out_local], dim=-1)))
            out = fg * out_branch + (1 - fg) * out_local
        else:
            out = out_branch

        return out, aux


class SwiGLU(nn.Module):
    def __init__(self, d, mult=2):
        super().__init__()
        h = d * mult
        self.w1 = nn.Linear(d, h, bias=False)
        self.w2 = nn.Linear(d, h, bias=False)
        self.w3 = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


class BranchCellV4(nn.Module):
    def __init__(self, vocab, d=128, n_layers=2, n_branch=8, top_k=None,
                 dk=24, dv=24, n_classes=3, dropout=0.1,
                 n_scales=3, local_win=32):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList()
        for _ in range(n_layers):
            self.blocks.append(nn.ModuleDict({
                'n1': RMSNorm(d),
                'mem': EfficientMultiScaleBranchMemory(
                    d, n_branch, top_k, dk, dv,
                    n_scales=n_scales, local_win=local_win),
                'n2': RMSNorm(d),
                'mlp': SwiGLU(d),
            }))
        self.norm_f = RMSNorm(d)
        self.head = nn.Linear(d, n_classes)
        self.aux_coef = 0.01

    def forward(self, x, return_aux=False):
        pad_mask = (x != 0)
        h = self.drop(self.emb(x))
        total_aux = h.new_zeros(())
        for blk in self.blocks:
            mem_out, aux = blk['mem'](blk['n1'](h))
            h = h + mem_out
            total_aux = total_aux + aux
            h = h + blk['mlp'](blk['n2'](h))
        h = self.norm_f(h)
        lengths = pad_mask.long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(x.size(0), device=x.device), lengths]
        logits = self.head(last)
        if return_aux:
            return logits, self.aux_coef * total_aux / len(self.blocks)
        return logits


class DecoderTransformer(nn.Module):
    def __init__(self, vocab, d=128, n_layers=2, n_heads=4, n_classes=3,
                 max_len=2048, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.pe = nn.Embedding(max_len, d)
        layer = nn.TransformerEncoderLayer(d, n_heads, d * 3, dropout, 'gelu',
                                           batch_first=True, norm_first=True)
        self.trf = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        B, T = x.shape
        pad_mask = (x == 0)
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        h = self.emb(x) + self.pe(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.trf(h, mask=causal, src_key_padding_mask=pad_mask)
        h = self.norm(h)
        lengths = (~pad_mask).long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(B, device=x.device), lengths]
        return self.head(last)
