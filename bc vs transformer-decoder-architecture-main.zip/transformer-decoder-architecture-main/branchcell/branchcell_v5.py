"""
BranchCell v5 — Hybrid Recurrent + Ring-Buffer Selective Memory.

THE BREAKTHROUGH: v2/v3/v4 failed Needle tasks because recurrent memory S
gradually FORGETS old information (gates < 1). Even with RoPE, once info is
written to S and many steps pass, it gets washed out by newer writes.

v5 adds a **RING BUFFER** of recent (k,v) pairs per branch:
  - A fixed-size circular buffer keeps the N most recent (key, value) pairs
  - Readout uses ATTENTION over the buffer: o_t = sum(softmax(q_t^T k_s) v_s)
  - This gives EXACT retrieval of recent information, immune to gate decay!
  - Combined with recurrent S for long-term summary (compressive memory)

Architecture per branch:
  1. Recurrent S: long-term summary (forget gates, compressive)
  2. Ring buffer B: short/medium exact retrieval (attention-based)
  3. Read: combine both via learned gate
  4. Write: update S AND append to B

The buffer is O(T * buf_size) per forward, but buf_size is constant (e.g., 64),
so overall is O(T). At inference, the buffer gives exact N-step recall.

This is the KEY to beating Transformer on Needle: we get the best of both:
  - Recurrent S: O(1) state, long-range (like v2/v3/v4)
  - Ring buffer: exact retrieval like attention, but bounded and O(T)

Additional improvements:
  - RoPE on buffer keys and queries (position-aware retrieval)
  - Hard routing of writes (from v3)
  - Output gating (GLA-style)
  - Depthwise conv (local n-grams)
  - Triple fusion across branches
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return self.w * x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)


def apply_rope(qk, positions):
    """RoPE. qk: (..., D), positions: (T,)"""
    *leading, D = qk.shape
    T = positions.shape[0]
    if D % 2 != 0:
        qk_p = F.pad(qk, (0, 1))
        out = apply_rope(qk_p, positions)
        return out[..., :D]
    dim_idx = torch.arange(0, D, 2, device=qk.device).float()
    inv_freq = 1.0 / (10000 ** (dim_idx / D))
    angles = torch.outer(positions.float(), inv_freq)
    cos, sin = torch.cos(angles), torch.sin(angles)
    # Reshape for rotation
    qk_r = qk.reshape(*leading, D // 2, 2)
    real, imag = qk_r[..., 0], qk_r[..., 1]
    # Broadcast cos/sin: (T, D//2) -> (1, T, 1, D//2) to match (*, T, *, D//2)
    c = cos.view(1, T, 1, D // 2)
    s = sin.view(1, T, 1, D // 2)
    out_r = real * c - imag * s
    out_i = real * s + imag * c
    return torch.stack([out_r, out_i], dim=-1).reshape(*leading, D)


class HybridBranchMemory(nn.Module):
    """Recurrent S + Ring Buffer B + Hard Routing + RoPE."""

    def __init__(self, d, n_branch=8, top_k=None, dk=24, dv=24, conv_k=4,
                 buf_size=64):
        super().__init__()
        self.nb = n_branch
        self.k = top_k if top_k is not None else max(1, n_branch // 2)
        self.dk, self.dv = dk, dv
        self.buf_size = buf_size

        # Projections
        self.Wq = nn.Linear(d, n_branch * dk, bias=False)
        self.Wk = nn.Linear(d, n_branch * dk, bias=False)
        self.Wv = nn.Linear(d, n_branch * dv, bias=False)

        # Forget gate for recurrent S
        self.Wg = nn.Linear(d, n_branch * dk, bias=True)
        nn.init.constant_(self.Wg.bias, 3.0)

        # Output gate
        self.Wog = nn.Linear(d, n_branch * dv, bias=True)

        # Router
        self.router = nn.Linear(d, n_branch, bias=False)

        # Depthwise conv
        self.conv_k = conv_k
        self.conv = nn.Conv1d(d, d, conv_k, groups=d, padding=0, bias=True)

        # Triple fusion
        self.gamma = nn.Parameter(torch.tensor(0.1))
        self.zeta = nn.Parameter(torch.tensor(0.2))

        # Fusion gate: recurrent vs buffer
        self.mem_fusion = nn.Linear(dv * 2, 1, bias=True)

        self.out = nn.Linear(dv, d, bias=False)

    def _route(self, x):
        logits = self.router(x)
        probs = F.softmax(logits, dim=-1)
        topv, topi = probs.topk(self.k, dim=-1)
        topv = topv / (topv.sum(-1, keepdim=True) + 1e-9)
        r = torch.zeros_like(probs).scatter_(-1, topi, topv)
        importance = probs.mean(dim=(0, 1))
        sel = torch.zeros_like(probs).scatter_(-1, topi, 1.0)
        load = sel.mean(dim=(0, 1))
        aux = self.nb * (importance * load).sum()
        return r, aux

    def forward(self, x):
        B, T, d = x.shape
        nb, dk, dv = self.nb, self.dk, self.dv
        bs = self.buf_size

        # Causal conv
        xc = F.pad(x.transpose(1, 2), (self.conv_k - 1, 0))
        xc = self.conv(xc).transpose(1, 2)
        xl = x + F.silu(xc)

        # Projections
        q = F.silu(self.Wq(xl)).view(B, T, nb, dk)
        k = F.silu(self.Wk(xl)).view(B, T, nb, dk)
        v = self.Wv(xl).view(B, T, nb, dv)
        g = torch.sigmoid(self.Wg(xl)).view(B, T, nb, dk)
        og = torch.sigmoid(self.Wog(xl)).view(B, T, nb, dv)
        r, aux = self._route(xl)

        # RoPE
        positions = torch.arange(T, device=x.device, dtype=torch.float32)
        q = apply_rope(q, positions)
        k = apply_rope(k, positions)

        # States
        S = x.new_zeros(B, nb, dk, dv)  # Recurrent state
        # Ring buffer: circular queue using cat (no in-place ops for grad safety)
        buf_k = x.new_zeros(B, nb, 0, dk)  # start empty, grow with cat
        buf_v = x.new_zeros(B, nb, 0, dv)

        outs = []
        for t in range(T):
            write = r[:, t].unsqueeze(-1).unsqueeze(-1)
            kv = k[:, t].unsqueeze(-1) * v[:, t].unsqueeze(-2)

            # Update recurrent S
            S = g[:, t].unsqueeze(-1) * S + write * kv
            o_s = torch.einsum('bnk,bnkv->bnv', q[:, t], S)

            # Update ring buffer: shift left, append new (no in-place!)
            new_k = k[:, t].unsqueeze(2)  # (B, nb, 1, dk)
            new_v = v[:, t].unsqueeze(2)  # (B, nb, 1, dv)
            buf_k = torch.cat([buf_k[:, :, -bs+1:], new_k], dim=2) if buf_k.shape[2] >= bs else torch.cat([buf_k, new_k], dim=2)
            buf_v = torch.cat([buf_v[:, :, -bs+1:], new_v], dim=2) if buf_v.shape[2] >= bs else torch.cat([buf_v, new_v], dim=2)

            # Read from buffer via attention
            scores = torch.einsum('bnk,bnmk->bnm', q[:, t], buf_k) / math.sqrt(dk)
            buf_probs = F.softmax(scores, dim=-1)
            o_b = torch.einsum('bnm,bnmv->bnv', buf_probs, buf_v)

            # Fuse recurrent and buffer
            fusion_in = torch.cat([o_s, o_b], dim=-1)  # (B, nb, 2*dv)
            fusion_gate = torch.sigmoid(self.mem_fusion(fusion_in))  # (B, nb, 1)
            o_t = fusion_gate * o_s + (1 - fusion_gate) * o_b
            outs.append(o_t)

        Z = torch.stack(outs, dim=1) * og  # (B, T, nb, dv)

        # Triple fusion
        lin = torch.einsum('btn,btnv->btv', r, Z)
        zr = Z * r.unsqueeze(-1)
        zs = zr.sum(dim=2)
        inter = self.gamma * ((zs ** 2) - (zr ** 2).sum(dim=2)) / 2
        comp = self.zeta * Z.max(dim=2)[0]
        fused = lin + inter + comp

        return self.out(fused), aux


class SwiGLU(nn.Module):
    def __init__(self, d, mult=2):
        super().__init__()
        h = d * mult
        self.w1 = nn.Linear(d, h, bias=False)
        self.w2 = nn.Linear(d, h, bias=False)
        self.w3 = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


class BranchCellV5(nn.Module):
    def __init__(self, vocab, d=128, n_layers=2, n_branch=8, top_k=None,
                 dk=24, dv=24, n_classes=3, dropout=0.1, buf_size=64):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList()
        for _ in range(n_layers):
            self.blocks.append(nn.ModuleDict({
                'n1': RMSNorm(d),
                'mem': HybridBranchMemory(d, n_branch, top_k, dk, dv, buf_size=buf_size),
                'n2': RMSNorm(d),
                'mlp': SwiGLU(d),
            }))
        self.norm_f = RMSNorm(d)
        self.head = nn.Linear(d, n_classes)
        self.aux_coef = 0.01

    def forward(self, x, return_aux=False):
        pad_mask = (x != 0)
        h = self.drop(self.emb(x))
        total_aux = h.new_zeros(())
        for blk in self.blocks:
            mem_out, aux = blk['mem'](blk['n1'](h))
            h = h + mem_out
            total_aux = total_aux + aux
            h = h + blk['mlp'](blk['n2'](h))
        h = self.norm_f(h)
        lengths = pad_mask.long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(x.size(0), device=x.device), lengths]
        logits = self.head(last)
        if return_aux:
            return logits, self.aux_coef * total_aux / len(self.blocks)
        return logits


class DecoderTransformer(nn.Module):
    def __init__(self, vocab, d=128, n_layers=2, n_heads=4, n_classes=3,
                 max_len=2048, dropout=0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.pe = nn.Embedding(max_len, d)
        layer = nn.TransformerEncoderLayer(d, n_heads, d * 3, dropout, 'gelu',
                                           batch_first=True, norm_first=True)
        self.trf = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_classes)

    def forward(self, x):
        B, T = x.shape
        pad_mask = (x == 0)
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        h = self.emb(x) + self.pe(pos)
        causal = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.trf(h, mask=causal, src_key_padding_mask=pad_mask)
        h = self.norm(h)
        lengths = (~pad_mask).long().sum(dim=1).clamp(min=1) - 1
        last = h[torch.arange(B, device=x.device), lengths]
        return self.head(last)
