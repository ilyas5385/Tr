"""
BranchCell v3 vs decoder-only Transformer — REASONING QUALITY + SPEED.

Fair protocol:
  - Both models: same width d, same depth, parameter-matched (+/- a few %).
  - Transformer = causal decoder-only (modern-AI standard).
  - Multiple seeds, mean +/- std reported.
  - Reasoning task suite (the thing we optimize for) + inference speed/throughput
    benchmark across sequence lengths (the linear-vs-quadratic story).

Writes results_v3.json and prints a full report.
"""
import json, time, random, math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from branchcell_v3 import BranchCellV3, DecoderTransformer


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)


# ----------------------------- tokenizer -----------------------------
class Tok:
    def __init__(self):
        self.w2i = {"<pad>": 0, "<unk>": 1}

    def build(self, texts):
        for t in texts:
            for w in t.split():
                if w not in self.w2i:
                    self.w2i[w] = len(self.w2i)

    @property
    def vocab(self):
        return len(self.w2i)

    def enc(self, t, L):
        ids = [self.w2i.get(w, 1) for w in t.split()][:L]
        return ids + [0] * (L - len(ids))


class DS(Dataset):
    def __init__(self, texts, labels, tok, L):
        self.x = [tok.enc(t, L) for t in texts]
        self.y = labels

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return torch.tensor(self.x[i]), torch.tensor(self.y[i])


# ----------------------------- REASONING tasks -----------------------------
NAMES = ["anna", "ben", "carl", "dora", "evan", "fay", "gus", "hana",
         "ivan", "july", "kim", "leo", "mona", "nora", "omar", "pia"]


def gen_multihop(n, hops=3):
    """Chain reasoning: follow a deterministic functional graph to its terminal.
    Each name has AT MOST one outgoing edge (no cycles), so the path is unique.
    'a->b . b->c . c->d . where does a arrive ?' -> d."""
    texts, labels = [], []
    for _ in range(n):
        names = random.sample(NAMES, len(NAMES))
        chain = names[:hops + 1]                    # distinct -> acyclic path
        facts = [f"{chain[i]} points to {chain[i+1]} ." for i in range(hops)]
        # distractors: sources NOT in the chain (keeps graph a function, terminal unique)
        free = names[hops + 1:]
        for j in range(min(2, len(free))):
            src = free[j]
            dst = random.choice([x for x in NAMES if x != src])
            facts.append(f"{src} points to {dst} .")
        random.shuffle(facts)                       # force real multi-hop, not order
        q = f"question : where does {chain[0]} finally arrive ?"
        endpoint = chain[-1]                         # terminal (no outgoing edge)
        cands = [endpoint] + random.sample([x for x in NAMES if x != endpoint], 3)
        random.shuffle(cands)
        lab = cands.index(endpoint)
        opts = "options : " + " ".join(f"{i} {c}" for i, c in enumerate(cands))
        texts.append(" ".join(facts) + " " + q + " " + opts)
        labels.append(lab)
    return texts, labels, 4


def gen_arithmetic(n):
    """Multi-step modular arithmetic reasoning. Track a running value."""
    texts, labels = [], []
    for _ in range(n):
        val = random.randint(0, 4)
        steps = [f"start {val} ."]
        for _ in range(random.randint(3, 5)):
            op = random.choice(["add", "sub"])
            k = random.randint(1, 3)
            if op == "add":
                val = (val + k) % 5
            else:
                val = (val - k) % 5
            steps.append(f"{op} {k} .")
        texts.append(" ".join(steps) + " question : final value mod 5 ?")
        labels.append(val)
    return texts, labels, 5


def gen_logic(n):
    """Boolean reasoning: evaluate a chain of and/or/not over flags."""
    texts, labels = [], []
    for _ in range(n):
        a, b, c = (random.randint(0, 1) for _ in range(3))
        facts = [f"p is {a} .", f"q is {b} .", f"s is {c} ."]
        random.shuffle(facts)
        form = random.choice([
            ("p and q", a and b),
            ("p or s", a or c),
            ("not p and s", (1 - a) and c),
            ("q or not s", b or (1 - c)),
            ("p and q or s", (a and b) or c),
        ])
        texts.append(" ".join(facts) + f" question : value of {form[0]} ?")
        labels.append(int(bool(form[1])))
    return texts, labels, 2


def gen_sort(n):
    """Comparative reasoning: who is the k-th largest among numbered items."""
    texts, labels = [], []
    for _ in range(n):
        people = random.sample(NAMES, 4)
        vals = random.sample(range(1, 30), 4)
        facts = [f"{p} has {v} ." for p, v in zip(people, vals)]
        random.shuffle(facts)
        order = sorted(range(4), key=lambda i: -vals[i])
        k = random.randint(0, 3)
        target = people[order[k]]
        cands = people[:]
        lab = cands.index(target)
        opts = "options : " + " ".join(f"{i} {c}" for i, c in enumerate(cands))
        texts.append(" ".join(facts) + f" question : who is rank {k} largest ? " + opts)
        labels.append(lab)
    return texts, labels, 4


# ----------------------------- train / eval -----------------------------
def count_params(m):
    return sum(p.numel() for p in m.parameters())


def run(model, trl, tel, epochs, is_branch):
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=2e-3, steps_per_epoch=len(trl), epochs=epochs)
    for _ in range(epochs):
        model.train()
        for xb, yb in trl:
            opt.zero_grad()
            if is_branch:
                logits, aux = model(xb, return_aux=True)
                loss = F.cross_entropy(logits, yb) + aux
            else:
                loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step()
    model.eval()
    correct = tot = 0
    with torch.no_grad():
        for xb, yb in tel:
            pred = model(xb).argmax(-1)
            correct += (pred == yb).sum().item(); tot += yb.numel()
    return correct / tot


def make_models(vocab, ncls, max_len):
    d, layers = 128, 2
    bc = BranchCellV3(vocab, d=d, n_layers=layers, n_branch=8, top_k=2,
                      dk=16, dv=16, n_classes=ncls)
    tr = DecoderTransformer(vocab, d=d, n_layers=layers, n_heads=4,
                            n_classes=ncls, max_len=max_len)
    return bc, tr


# ----------------------------- speed benchmark -----------------------------
def bench_speed(vocab):
    print("\n" + "=" * 64)
    print("SPEED / THROUGHPUT  (inference, CPU, batch=8)")
    print("=" * 64)
    print(f"{'seqlen':>8} | {'BranchCell ms':>14} | {'Transformer ms':>15} | {'speedup':>8}")
    print("-" * 64)
    rows = []
    for T in [64, 128, 256, 512, 1024]:
        bc, tr = make_models(vocab, 3, max_len=2048)
        bc.eval(); tr.eval()
        x = torch.randint(1, vocab, (8, T))
        with torch.no_grad():
            for _ in range(2):                      # warmup
                bc(x); tr(x)
            t0 = time.time()
            for _ in range(5):
                bc(x)
            bt = (time.time() - t0) / 5 * 1000
            t0 = time.time()
            for _ in range(5):
                tr(x)
            tt = (time.time() - t0) / 5 * 1000
        speedup = tt / bt
        rows.append({"seqlen": T, "branchcell_ms": bt, "transformer_ms": tt,
                     "speedup": speedup})
        print(f"{T:>8} | {bt:>14.1f} | {tt:>15.1f} | {speedup:>7.2f}x")
    return rows


# ----------------------------- main -----------------------------
def main():
    seeds = [42, 123]
    epochs = 8
    tasks = [
        ("MultiHop",   lambda: gen_multihop(1400, hops=3), 64),
        ("Arithmetic", lambda: gen_arithmetic(1400),       48),
        ("Logic",      lambda: gen_logic(1200),            40),
        ("RankSort",   lambda: gen_sort(1400),             48),
    ]
    results = {"tasks": {}, "speed": None, "params": {}}

    print("=" * 64)
    print("BranchCell v3 (hard-routed)  vs  decoder-only Transformer")
    print("REASONING SUITE  —  mean over seeds", seeds)
    print("=" * 64)

    vocab_for_speed = None
    for tname, gen, L in tasks:
        bc_accs, tr_accs = [], []
        for s in seeds:
            set_seed(s)
            texts, labels, ncls = gen()
            tok = Tok(); tok.build(texts)
            if vocab_for_speed is None:
                vocab_for_speed = tok.vocab
            idx = list(range(len(texts))); random.shuffle(idx)
            cut = int(0.8 * len(texts))
            tr_idx, te_idx = idx[:cut], idx[cut:]
            trl = DataLoader(DS([texts[i] for i in tr_idx], [labels[i] for i in tr_idx],
                                tok, L), batch_size=32, shuffle=True)
            tel = DataLoader(DS([texts[i] for i in te_idx], [labels[i] for i in te_idx],
                                tok, L), batch_size=64)
            bc, tr = make_models(tok.vocab, ncls, L)
            results["params"]["BranchCell"] = count_params(bc)
            results["params"]["Transformer"] = count_params(tr)
            bc_accs.append(run(bc, trl, tel, epochs, is_branch=True))
            tr_accs.append(run(tr, trl, tel, epochs, is_branch=False))
        bm, bs = float(np.mean(bc_accs)), float(np.std(bc_accs))
        tm, ts = float(np.mean(tr_accs)), float(np.std(tr_accs))
        results["tasks"][tname] = {"branchcell": [bm, bs], "transformer": [tm, ts]}
        win = "BranchCell" if bm > tm else ("Transformer" if tm > bm else "tie")
        print(f"\n{tname:>11} (chance {1.0/ncls:.2f})")
        print(f"    BranchCell  : {bm:.3f} +/- {bs:.3f}")
        print(f"    Transformer : {tm:.3f} +/- {ts:.3f}")
        print(f"    -> winner: {win}  (delta {bm - tm:+.3f})")

    results["speed"] = bench_speed(vocab_for_speed)

    # summary
    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    print(f"Params: BranchCell {results['params']['BranchCell']:,} | "
          f"Transformer {results['params']['Transformer']:,}")
    bwin = sum(1 for t in results["tasks"].values()
               if t["branchcell"][0] > t["transformer"][0])
    print(f"Reasoning tasks won by BranchCell: {bwin}/{len(results['tasks'])}")
    avg_speedup = np.mean([r["speedup"] for r in results["speed"]])
    big_speedup = results["speed"][-1]["speedup"]
    print(f"Avg inference speedup: {avg_speedup:.2f}x | at seqlen 1024: {big_speedup:.2f}x")

    with open("results_v3.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved results_v3.json")


if __name__ == "__main__":
    main()
