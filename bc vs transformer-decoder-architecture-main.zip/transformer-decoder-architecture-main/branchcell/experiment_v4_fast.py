"""
BranchCell v4 vs Transformer — FAST but FAIR benchmark.
Same protocol, reduced scale for quick iteration while keeping statistical power.
"""
import json, time, random, math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from branchcell_v4 import BranchCellV4, DecoderTransformer


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)


class Tok:
    def __init__(self):
        self.w2i = {"<pad>": 0, "<unk>": 1}

    def build(self, texts):
        for t in texts:
            for w in t.split():
                if w not in self.w2i:
                    self.w2i[w] = len(self.w2i)

    @property
    def vocab(self):
        return len(self.w2i)

    def enc(self, t, L):
        ids = [self.w2i.get(w, 1) for w in t.split()][:L]
        return ids + [0] * (L - len(ids))


class DS(Dataset):
    def __init__(self, texts, labels, tok, L):
        self.x = [tok.enc(t, L) for t in texts]
        self.y = labels

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return torch.tensor(self.x[i]), torch.tensor(self.y[i])


NAMES = ["anna", "ben", "carl", "dora", "evan", "fay", "gus", "hana",
         "ivan", "july", "kim", "leo", "mona", "nora", "omar", "pia"]


def gen_multihop(n, hops=3):
    texts, labels = [], []
    for _ in range(n):
        names = random.sample(NAMES, len(NAMES))
        chain = names[:hops + 1]
        facts = [f"{chain[i]} points to {chain[i+1]} ." for i in range(hops)]
        free = names[hops + 1:]
        for j in range(min(2, len(free))):
            src = free[j]
            dst = random.choice([x for x in NAMES if x != src])
            facts.append(f"{src} points to {dst} .")
        random.shuffle(facts)
        q = f"question : where does {chain[0]} finally arrive ?"
        endpoint = chain[-1]
        cands = [endpoint] + random.sample([x for x in NAMES if x != endpoint], 3)
        random.shuffle(cands)
        lab = cands.index(endpoint)
        opts = "options : " + " ".join(f"{i} {c}" for i, c in enumerate(cands))
        texts.append(" ".join(facts) + " " + q + " " + opts)
        labels.append(lab)
    return texts, labels, 4


def gen_arithmetic(n):
    texts, labels = [], []
    for _ in range(n):
        val = random.randint(0, 4)
        steps = [f"start {val} ."]
        for _ in range(random.randint(3, 5)):
            op = random.choice(["add", "sub"])
            k = random.randint(1, 3)
            val = (val + k) % 5 if op == "add" else (val - k) % 5
            steps.append(f"{op} {k} .")
        texts.append(" ".join(steps) + " question : final value mod 5 ?")
        labels.append(val)
    return texts, labels, 5


def gen_logic(n):
    texts, labels = [], []
    for _ in range(n):
        a, b, c = (random.randint(0, 1) for _ in range(3))
        facts = [f"p is {a} .", f"q is {b} .", f"s is {c} ."]
        random.shuffle(facts)
        form = random.choice([
            ("p and q", a and b),
            ("p or s", a or c),
            ("not p and s", (1 - a) and c),
            ("q or not s", b or (1 - c)),
            ("p and q or s", (a and b) or c),
        ])
        texts.append(" ".join(facts) + f" question : value of {form[0]} ?")
        labels.append(int(bool(form[1])))
    return texts, labels, 2


def gen_sort(n):
    texts, labels = [], []
    for _ in range(n):
        people = random.sample(NAMES, 4)
        vals = random.sample(range(1, 30), 4)
        facts = [f"{p} has {v} ." for p, v in zip(people, vals)]
        random.shuffle(facts)
        order = sorted(range(4), key=lambda i: -vals[i])
        k = random.randint(0, 3)
        target = people[order[k]]
        cands = people[:]
        lab = cands.index(target)
        opts = "options : " + " ".join(f"{i} {c}" for i, c in enumerate(cands))
        texts.append(" ".join(facts) + f" question : who is rank {k} largest ? " + opts)
        labels.append(lab)
    return texts, labels, 4


KEYS = ["sunshine", "galaxy", "horizon", "mountain", "river", "thunder",
        "crystal", "ember", "willow", "falcon"]
FILLER = ["the weather was pleasant that day .", "many people attended the event .",
          "coffee was served in the lobby .", "the discussion lasted for hours .",
          "several documents were reviewed carefully .", "the team made steady progress .",
          "the room had large windows facing the garden .", "lunch was provided at noon .",
          "the schedule was updated twice .", "notes were taken by the assistant ."]


def gen_needle(n, ctx_words=128):
    texts, labels = [], []
    for _ in range(n):
        key = random.randrange(len(KEYS))
        fact = f"remember this : the secret code is {KEYS[key]} ."
        sents = []
        while sum(len(s.split()) for s in sents) < ctx_words - 14:
            sents.append(random.choice(FILLER))
        pos = random.randint(0, len(sents))
        sents.insert(pos, fact)
        texts.append(" ".join(sents) + " question : what is the secret code ?")
        labels.append(key)
    return texts, labels, len(KEYS)


def count_params(m):
    return sum(p.numel() for p in m.parameters())


def run(model, trl, tel, epochs, is_branch):
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=2e-3, steps_per_epoch=len(trl), epochs=epochs)
    for _ in range(epochs):
        model.train()
        for xb, yb in trl:
            opt.zero_grad()
            if is_branch:
                logits, aux = model(xb, return_aux=True)
                loss = F.cross_entropy(logits, yb) + aux
            else:
                loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step()
    model.eval()
    correct = tot = 0
    with torch.no_grad():
        for xb, yb in tel:
            pred = model(xb).argmax(-1)
            correct += (pred == yb).sum().item(); tot += yb.numel()
    return correct / tot


def make_models(vocab, ncls, max_len):
    d, layers = 128, 2
    bc = BranchCellV4(vocab, d=d, n_layers=layers, n_branch=8, top_k=2,
                      dk=16, dv=16, n_classes=ncls,
                      n_scales=3, local_win=32)
    tr = DecoderTransformer(vocab, d=d, n_layers=layers, n_heads=4,
                            n_classes=ncls, max_len=max_len)
    return bc, tr


def bench_speed(vocab):
    print("\n" + "=" * 64)
    print("SPEED / THROUGHPUT  (inference, CPU, batch=8)")
    print("=" * 64)
    print(f"{'seqlen':>8} | {'BranchCellV4 ms':>16} | {'Transformer ms':>15} | {'speedup':>8}")
    print("-" * 64)
    rows = []
    for T in [64, 128, 256, 512, 1024]:
        bc, tr = make_models(vocab, 3, max_len=2048)
        bc.eval(); tr.eval()
        x = torch.randint(1, vocab, (8, T))
        with torch.no_grad():
            for _ in range(2):
                bc(x); tr(x)
            t0 = time.time()
            for _ in range(5):
                bc(x)
            bt = (time.time() - t0) / 5 * 1000
            t0 = time.time()
            for _ in range(5):
                tr(x)
            tt = (time.time() - t0) / 5 * 1000
        speedup = tt / bt if bt > 0 else 999
        rows.append({"seqlen": T, "branchcell_ms": bt, "transformer_ms": tt,
                     "speedup": speedup})
        print(f"{T:>8} | {bt:>16.1f} | {tt:>15.1f} | {speedup:>7.2f}x")
    return rows


def main():
    seeds = [42, 123]
    epochs = 8
    tasks = [
        ("MultiHop",   lambda: gen_multihop(1200, hops=3), 64),
        ("Arithmetic", lambda: gen_arithmetic(1200),       48),
        ("Logic",      lambda: gen_logic(1000),            40),
        ("RankSort",   lambda: gen_sort(1200),             48),
        ("Needle128",  lambda: gen_needle(700, 128),       144),
        ("Needle256",  lambda: gen_needle(600, 256),       272),
    ]
    results = {"tasks": {}, "speed": None, "params": {}}

    print("=" * 64)
    print("BranchCell v4  vs  Transformer — FAST FAIR BENCHMARK")
    print("=" * 64)

    vocab_for_speed = None
    for tname, gen, L in tasks:
        bc_accs, tr_accs = [], []
        for s in seeds:
            set_seed(s)
            texts, labels, ncls = gen()
            tok = Tok(); tok.build(texts)
            if vocab_for_speed is None:
                vocab_for_speed = tok.vocab
            idx = list(range(len(texts))); random.shuffle(idx)
            cut = int(0.8 * len(texts))
            tr_idx, te_idx = idx[:cut], idx[cut:]
            trl = DataLoader(DS([texts[i] for i in tr_idx], [labels[i] for i in tr_idx],
                                tok, L), batch_size=32, shuffle=True)
            tel = DataLoader(DS([texts[i] for i in te_idx], [labels[i] for i in te_idx],
                                tok, L), batch_size=64)
            bc, tr = make_models(tok.vocab, ncls, L)
            results["params"]["BranchCellV4"] = count_params(bc)
            results["params"]["Transformer"] = count_params(tr)
            bc_accs.append(run(bc, trl, tel, epochs, is_branch=True))
            tr_accs.append(run(tr, trl, tel, epochs, is_branch=False))
        bm, bs = float(np.mean(bc_accs)), float(np.std(bc_accs))
        tm, ts = float(np.mean(tr_accs)), float(np.std(tr_accs))
        results["tasks"][tname] = {"branchcell": [bm, bs], "transformer": [tm, ts]}
        win = "BranchCell" if bm > tm else ("Transformer" if tm > bm else "tie")
        delta = bm - tm
        bar = "█" * max(0, int(delta * 50)) if delta > 0 else "░" * max(0, int(-delta * 50))
        print(f"\n{tname:>11} (chance {1.0/ncls:.2f})")
        print(f"    BranchCellV4 : {bm:.3f} ± {bs:.3f}")
        print(f"    Transformer  : {tm:.3f} ± {ts:.3f}")
        print(f"    -> {win}  (delta {delta:+.3f}) {bar}")

    results["speed"] = bench_speed(vocab_for_speed)

    # Summary
    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    print(f"Params: BranchCellV4 {results['params']['BranchCellV4']:,} | "
          f"Transformer {results['params']['Transformer']:,}")
    
    bwin = sum(1 for t in results["tasks"].values()
               if t["branchcell"][0] > t["transformer"][0])
    twin = sum(1 for t in results["tasks"].values()
               if t["transformer"][0] > t["branchcell"][0])
    ties = len(results["tasks"]) - bwin - twin
    print(f"Tasks won: BranchCellV4={bwin} | Transformer={twin} | Ties={ties} / {len(results['tasks'])}")
    
    # Per-category averages
    reasoning_tasks = ["MultiHop", "Arithmetic", "Logic", "RankSort"]
    needle_tasks = ["Needle128", "Needle256"]
    
    if all(t in results["tasks"] for t in reasoning_tasks):
        rbc = np.mean([results["tasks"][t]["branchcell"][0] for t in reasoning_tasks])
        rtr = np.mean([results["tasks"][t]["transformer"][0] for t in reasoning_tasks])
        print(f"\nReasoning avg: BranchCellV4={rbc:.3f} | Transformer={rtr:.3f}")
    
    if all(t in results["tasks"] for t in needle_tasks):
        nbc = np.mean([results["tasks"][t]["branchcell"][0] for t in needle_tasks])
        ntr = np.mean([results["tasks"][t]["transformer"][0] for t in needle_tasks])
        print(f"Needle avg:    BranchCellV4={nbc:.3f} | Transformer={ntr:.3f}")
        print(f"Needle improvement over v2: {nbc - 0.247:.3f} (v2 was ~0.247)")
    
    avg_speedup = np.mean([r["speedup"] for r in results["speed"]])
    big_speedup = results["speed"][-1]["speedup"]
    print(f"\nSpeed: Avg {avg_speedup:.2f}x | At 1024: {big_speedup:.2f}x")

    # v2 comparison
    print("\n" + "=" * 64)
    print("v2 -> v4 PROGRESS CHECK")
    print("=" * 64)
    v2_map = {"MultiHop": 0.3625, "Needle128": 0.341, "Needle256": 0.154}
    for t, v2_val in v2_map.items():
        if t in results["tasks"]:
            v4_val = results["tasks"][t]["branchcell"][0]
            print(f"  {t:<12} v2={v2_val:.3f} -> v4={v4_val:.3f}  (delta {v4_val-v2_val:+.3f})")

    with open("results_v4_fast.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved results_v4_fast.json")


if __name__ == "__main__":
    main()
