"""BranchCell v5 vs Transformer — MICRO BENCHMARK (d=48, 200 samples, 4 epochs)."""
import json, time, random, math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from branchcell_v5 import BranchCellV5, DecoderTransformer

def set_seed(s): random.seed(s); np.random.seed(s); torch.manual_seed(s)

class Tok:
    def __init__(self): self.w2i = {"<pad>": 0, "<unk>": 1}
    def build(self, texts):
        for t in texts:
            for w in t.split():
                if w not in self.w2i: self.w2i[w] = len(self.w2i)
    @property
    def vocab(self): return len(self.w2i)
    def enc(self, t, L):
        ids = [self.w2i.get(w, 1) for w in t.split()][:L]
        return ids + [0] * (L - len(ids))

class DS(Dataset):
    def __init__(self, texts, labels, tok, L):
        self.x = [tok.enc(t, L) for t in texts]; self.y = labels
    def __len__(self): return len(self.y)
    def __getitem__(self, i): return torch.tensor(self.x[i]), torch.tensor(self.y[i])

NAMES = ["anna","ben","carl","dora","evan","fay","gus","hana","ivan","july","kim","leo","mona","nora","omar","pia"]

def gen_multihop(n, hops=3):
    texts, labels = [], []
    for _ in range(n):
        names = random.sample(NAMES, len(NAMES))
        chain = names[:hops+1]
        facts = [f"{chain[i]} points to {chain[i+1]} ." for i in range(hops)]
        facts += [f"{names[hops+1]} points to {random.choice(NAMES)} ."]
        random.shuffle(facts)
        cands = [chain[-1]] + random.sample([x for x in NAMES if x != chain[-1]], 3)
        random.shuffle(cands)
        lab = cands.index(chain[-1])
        opts = "options : " + " ".join(f"{i} {c}" for i,c in enumerate(cands))
        texts.append(" ".join(facts) + f" question : where does {chain[0]} finally arrive ? " + opts)
        labels.append(lab)
    return texts, labels, 4

def gen_arithmetic(n):
    texts, labels = [], []
    for _ in range(n):
        val = random.randint(0,4); steps = [f"start {val} ."]
        for _ in range(random.randint(3,5)):
            op = random.choice(["add","sub"]); k = random.randint(1,3)
            val = (val+k)%5 if op=="add" else (val-k)%5
            steps.append(f"{op} {k} .")
        texts.append(" ".join(steps) + " question : final value mod 5 ?")
        labels.append(val)
    return texts, labels, 5

def gen_logic(n):
    texts, labels = [], []
    for _ in range(n):
        a,b,c = (random.randint(0,1) for _ in range(3))
        facts = [f"p is {a} .", f"q is {b} .", f"s is {c} ."]
        random.shuffle(facts)
        form = random.choice([("p and q",a and b),("p or s",a or c),("not p and s",(1-a) and c),("q or not s",b or (1-c)),("p and q or s",(a and b) or c)])
        texts.append(" ".join(facts) + f" question : value of {form[0]} ?")
        labels.append(int(bool(form[1])))
    return texts, labels, 2

def gen_sort(n):
    texts, labels = [], []
    for _ in range(n):
        people = random.sample(NAMES,4); vals = random.sample(range(1,30),4)
        facts = [f"{p} has {v} ." for p,v in zip(people,vals)]
        random.shuffle(facts)
        order = sorted(range(4), key=lambda i: -vals[i])
        k = random.randint(0,3); target = people[order[k]]
        cands = people[:]; lab = cands.index(target)
        opts = "options : " + " ".join(f"{i} {c}" for i,c in enumerate(cands))
        texts.append(" ".join(facts) + f" question : who is rank {k} largest ? " + opts)
        labels.append(lab)
    return texts, labels, 4

KEYS = ["sunshine","galaxy","horizon","mountain","river","thunder","crystal","ember","willow","falcon"]
FILLER = ["the weather was pleasant .","many people attended .","coffee was served .","the discussion lasted .","documents were reviewed ."]

def gen_needle(n, ctx_words=64):
    texts, labels = [], []
    for _ in range(n):
        key = random.randrange(len(KEYS))
        fact = f"remember this : the secret code is {KEYS[key]} ."
        sents = []
        while sum(len(s.split()) for s in sents) < ctx_words - 10:
            sents.append(random.choice(FILLER))
        sents.insert(random.randint(0,len(sents)), fact)
        texts.append(" ".join(sents) + " question : what is the secret code ?")
        labels.append(key)
    return texts, labels, len(KEYS)

def count_params(m): return sum(p.numel() for p in m.parameters())

def run(model, trl, tel, epochs, is_branch):
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3, weight_decay=0.01)
    for _ in range(epochs):
        model.train()
        for xb,yb in trl:
            opt.zero_grad()
            if is_branch:
                logits, aux = model(xb, return_aux=True)
                loss = F.cross_entropy(logits, yb) + aux
            else:
                loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
    model.eval()
    correct = tot = 0
    with torch.no_grad():
        for xb,yb in tel:
            pred = model(xb).argmax(-1)
            correct += (pred==yb).sum().item(); tot += yb.numel()
    return correct/tot

def make_models(vocab, ncls, max_len):
    bc = BranchCellV5(vocab, d=48, n_layers=2, n_branch=4, top_k=2, dk=12, dv=12, n_classes=ncls, buf_size=64)
    tr = DecoderTransformer(vocab, d=48, n_layers=2, n_heads=4, n_classes=ncls, max_len=max_len)
    return bc, tr

def bench_speed(vocab):
    print("\n" + "="*50)
    print("SPEED / THROUGHPUT (inference, CPU, batch=8)")
    print("="*50)
    print(f"{'seqlen':>8} | {'BCv5 ms':>12} | {'TRF ms':>12} | {'speedup':>8}")
    print("-"*50)
    rows = []
    for T in [64,128,256,512,1024]:
        bc, tr = make_models(vocab, 3, 2048)
        bc.eval(); tr.eval()
        x = torch.randint(1, vocab, (8,T))
        with torch.no_grad():
            for _ in range(2): bc(x); tr(x)
            t0 = time.time()
            for _ in range(5): bc(x)
            bt = (time.time()-t0)/5*1000
            t0 = time.time()
            for _ in range(5): tr(x)
            tt = (time.time()-t0)/5*1000
        sp = tt/bt if bt>0 else 999
        rows.append({"seqlen":T, "branchcell_ms":bt, "transformer_ms":tt, "speedup":sp})
        print(f"{T:>8} | {bt:>12.1f} | {tt:>12.1f} | {sp:>7.2f}x")
    return rows

def main():
    seeds = [42, 123]
    epochs = 4
    tasks = [
        ("MultiHop",   lambda: gen_multihop(200, hops=3), 48),
        ("Arithmetic", lambda: gen_arithmetic(200),       36),
        ("Logic",      lambda: gen_logic(160),            32),
        ("RankSort",   lambda: gen_sort(200),             36),
        ("Needle64",   lambda: gen_needle(160, 64),       80),
        ("Needle128",  lambda: gen_needle(140, 128),      144),
    ]
    results = {"tasks":{}, "speed":None, "params":{}, "version":"v5"}
    
    print("="*50)
    print("BranchCell v5 vs Transformer — MICRO BENCHMARK")
    print("d=48, 200 samples, 4 epochs")
    print("="*50)
    
    vocab_for_speed = None
    for tname, gen, L in tasks:
        bc_accs, tr_accs = [], []
        for s in seeds:
            set_seed(s)
            texts, labels, ncls = gen()
            tok = Tok(); tok.build(texts)
            if vocab_for_speed is None: vocab_for_speed = tok.vocab
            idx = list(range(len(texts))); random.shuffle(idx)
            cut = int(0.8*len(texts))
            trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, L), batch_size=16, shuffle=True)
            tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, L), batch_size=32)
            bc, tr = make_models(tok.vocab, ncls, L)
            results["params"]["BranchCellV5"] = count_params(bc)
            results["params"]["Transformer"] = count_params(tr)
            bc_accs.append(run(bc, trl, tel, epochs, True))
            tr_accs.append(run(tr, trl, tel, epochs, False))
        bm, bs = float(np.mean(bc_accs)), float(np.std(bc_accs))
        tm, ts = float(np.mean(tr_accs)), float(np.std(tr_accs))
        results["tasks"][tname] = {"branchcell":[bm,bs], "transformer":[tm,ts]}
        win = "BranchCell" if bm>tm else ("Transformer" if tm>bm else "tie")
        print(f"\n{tname:>10} (chance {1.0/ncls:.2f})")
        print(f"  BCv5: {bm:.3f} ± {bs:.3f}")
        print(f"  TRF:  {tm:.3f} ± {ts:.3f}")
        print(f"  -> {win}  (delta {bm-tm:+.3f})")
    
    results["speed"] = bench_speed(vocab_for_speed)
    
    print("\n" + "="*50)
    print("SUMMARY")
    print("="*50)
    print(f"Params: BCv5 {results['params']['BranchCellV5']:,} | TRF {results['params']['Transformer']:,}")
    bwin = sum(1 for t in results["tasks"].values() if t["branchcell"][0] > t["transformer"][0])
    twin = sum(1 for t in results["tasks"].values() if t["transformer"][0] > t["branchcell"][0])
    print(f"Won: BCv5={bwin} | TRF={twin} / {len(results['tasks'])}")
    
    rtasks = ["MultiHop","Arithmetic","Logic","RankSort"]
    ntasks = ["Needle64","Needle128"]
    print(f"Reasoning avg: BC={np.mean([results['tasks'][t]['branchcell'][0] for t in rtasks]):.3f} | TR={np.mean([results['tasks'][t]['transformer'][0] for t in rtasks]):.3f}")
    print(f"Needle avg:    BC={np.mean([results['tasks'][t]['branchcell'][0] for t in ntasks]):.3f} | TR={np.mean([results['tasks'][t]['transformer'][0] for t in ntasks]):.3f}")
    
    # v2 comparison
    print(f"\nv2→v5 Needle128: {0.341:.3f}→{results['tasks']['Needle128']['branchcell'][0]:.3f}")
    sp = np.mean([r["speedup"] for r in results["speed"]])
    print(f"Speed avg: {sp:.2f}x")
    
    with open("results_v5_micro.json","w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved results_v5_micro.json")

if __name__ == "__main__":
    main()
