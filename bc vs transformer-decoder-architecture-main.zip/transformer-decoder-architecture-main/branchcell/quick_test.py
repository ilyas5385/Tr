import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import random, numpy as np
from branchcell_v4 import BranchCellV4, DecoderTransformer

def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)

class Tok:
    def __init__(self):
        self.w2i = {'<pad>': 0, '<unk>': 1}
    def build(self, texts):
        for t in texts:
            for w in t.split():
                if w not in self.w2i:
                    self.w2i[w] = len(self.w2i)
    @property
    def vocab(self):
        return len(self.w2i)
    def enc(self, t, L):
        ids = [self.w2i.get(w, 1) for w in t.split()][:L]
        return ids + [0] * (L - len(ids))

class DS(Dataset):
    def __init__(self, texts, labels, tok, L):
        self.x = [tok.enc(t, L) for t in texts]
        self.y = labels
    def __len__(self):
        return len(self.y)
    def __getitem__(self, i):
        return torch.tensor(self.x[i]), torch.tensor(self.y[i])

NAMES = ['anna', 'ben', 'carl', 'dora', 'evan', 'fay', 'gus', 'hana']

def gen_multihop(n, hops=3):
    texts, labels = [], []
    for _ in range(n):
        names = random.sample(NAMES, len(NAMES))
        chain = names[:hops + 1]
        facts = [f'{chain[i]} points to {chain[i+1]} .' for i in range(hops)]
        free = names[hops + 1:]
        for j in range(min(2, len(free))):
            src = free[j]
            dst = random.choice([x for x in NAMES if x != src])
            facts.append(f'{src} points to {dst} .')
        random.shuffle(facts)
        q = f'question : where does {chain[0]} finally arrive ?'
        endpoint = chain[-1]
        cands = [endpoint] + random.sample([x for x in NAMES if x != endpoint], 3)
        random.shuffle(cands)
        lab = cands.index(endpoint)
        opts = 'options : ' + ' '.join(f'{i} {c}' for i, c in enumerate(cands))
        texts.append(' '.join(facts) + ' ' + q + ' ' + opts)
        labels.append(lab)
    return texts, labels, 4

def gen_needle(n, ctx_words=128):
    KEYS = ['sunshine', 'galaxy', 'horizon', 'mountain', 'river', 'thunder',
            'crystal', 'ember', 'willow', 'falcon']
    FILLER = ['the weather was pleasant that day .', 'many people attended the event .',
              'coffee was served in the lobby .', 'the discussion lasted for hours .',
              'several documents were reviewed carefully .', 'the team made steady progress .',
              'the room had large windows facing the garden .', 'lunch was provided at noon .',
              'the schedule was updated twice .', 'notes were taken by the assistant .']
    texts, labels = [], []
    for _ in range(n):
        key = random.randrange(len(KEYS))
        fact = f'remember this : the secret code is {KEYS[key]} .'
        sents = []
        while sum(len(s.split()) for s in sents) < ctx_words - 14:
            sents.append(random.choice(FILLER))
        pos = random.randint(0, len(sents))
        sents.insert(pos, fact)
        texts.append(' '.join(sents) + ' question : what is the secret code ?')
        labels.append(key)
    return texts, labels, len(KEYS)

def run_quick(model, trl, tel, epochs, is_branch):
    opt = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.01)
    for e in range(epochs):
        model.train()
        for xb, yb in trl:
            opt.zero_grad()
            if is_branch:
                logits, aux = model(xb, return_aux=True)
                loss = F.cross_entropy(logits, yb) + aux
            else:
                loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
    model.eval()
    correct = tot = 0
    with torch.no_grad():
        for xb, yb in tel:
            pred = model(xb).argmax(-1)
            correct += (pred == yb).sum().item(); tot += yb.numel()
    return correct / tot

print("="*60)
print("BranchCell v4 Quick Validation")
print("="*60)

# Test 1: MultiHop
set_seed(42)
texts, labels, ncls = gen_multihop(200, hops=3)
tok = Tok(); tok.build(texts)
idx = list(range(len(texts))); random.shuffle(idx)
cut = int(0.8 * len(texts))
trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, 64), batch_size=16, shuffle=True)
tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, 64), batch_size=32)

bc = BranchCellV4(tok.vocab, d=64, n_layers=2, n_branch=4, top_k=2, dk=16, dv=16, n_classes=ncls, n_scales=3, local_win=16)
tr = DecoderTransformer(tok.vocab, d=64, n_layers=2, n_heads=4, n_classes=ncls, max_len=128)

bc_acc = run_quick(bc, trl, tel, 6, is_branch=True)
tr_acc = run_quick(tr, trl, tel, 6, is_branch=False)

print(f"\n[1] MultiHop (chance=0.25):")
print(f"    BranchCellV4: {bc_acc:.3f}")
print(f"    Transformer:  {tr_acc:.3f}")
print(f"    Winner: {'BranchCell' if bc_acc > tr_acc else 'Transformer'} (delta {bc_acc-tr_acc:+.3f})")

# Test 2: Needle128
set_seed(42)
texts, labels, ncls = gen_needle(200, ctx_words=128)
tok = Tok(); tok.build(texts)
idx = list(range(len(texts))); random.shuffle(idx)
cut = int(0.8 * len(texts))
trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, 144), batch_size=16, shuffle=True)
tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, 144), batch_size=32)

bc = BranchCellV4(tok.vocab, d=64, n_layers=2, n_branch=4, top_k=2, dk=16, dv=16, n_classes=ncls, n_scales=3, local_win=16)
tr = DecoderTransformer(tok.vocab, d=64, n_layers=2, n_heads=4, n_classes=ncls, max_len=256)

bc_acc = run_quick(bc, trl, tel, 8, is_branch=True)
tr_acc = run_quick(tr, trl, tel, 8, is_branch=False)

print(f"\n[2] Needle128 (chance=0.10):")
print(f"    BranchCellV4: {bc_acc:.3f}")
print(f"    Transformer:  {tr_acc:.3f}")
print(f"    Winner: {'BranchCell' if bc_acc > tr_acc else 'Transformer'} (delta {bc_acc-tr_acc:+.3f})")
print(f"    v2 baseline:  BC=0.341, TR=1.000")

# Test 3: Needle256
set_seed(42)
texts, labels, ncls = gen_needle(150, ctx_words=256)
tok = Tok(); tok.build(texts)
idx = list(range(len(texts))); random.shuffle(idx)
cut = int(0.8 * len(texts))
trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, 272), batch_size=12, shuffle=True)
tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, 272), batch_size=24)

bc = BranchCellV4(tok.vocab, d=64, n_layers=2, n_branch=4, top_k=2, dk=16, dv=16, n_classes=ncls, n_scales=3, local_win=16)
tr = DecoderTransformer(tok.vocab, d=64, n_layers=2, n_heads=4, n_classes=ncls, max_len=512)

bc_acc = run_quick(bc, trl, tel, 8, is_branch=True)
tr_acc = run_quick(tr, trl, tel, 8, is_branch=False)

print(f"\n[3] Needle256 (chance=0.10):")
print(f"    BranchCellV4: {bc_acc:.3f}")
print(f"    Transformer:  {tr_acc:.3f}")
print(f"    Winner: {'BranchCell' if bc_acc > tr_acc else 'Transformer'} (delta {bc_acc-tr_acc:+.3f})")
print(f"    v2 baseline:  BC=0.154, TR=0.789")

print("\n" + "="*60)
print("Validation complete!")
print("="*60)
