"""Correctness tests for BranchCell v2."""
import torch
import torch.nn.functional as F
from branchcell_v2 import BranchMemory, BranchCellV2, DecoderTransformer

torch.manual_seed(0)


def naive_reference(mem: BranchMemory, x):
    """Sequential O(T) reference implementation of the same recurrence."""
    B, T, _ = x.shape
    nb, dk, dv = mem.nb, mem.dk, mem.dv
    q = F.silu(mem.Wq(x)).view(B, T, nb, dk)
    k = F.silu(mem.Wk(x)).view(B, T, nb, dk)
    v = mem.Wv(x).view(B, T, nb, dv)
    g = 0.5 + 0.5 * torch.sigmoid(mem.Wg(x)).view(B, T, nb, dk)
    S = x.new_zeros(B, nb, dk, dv)
    outs = []
    for t in range(T):
        S = g[:, t].unsqueeze(-1) * S + k[:, t].unsqueeze(-1) * v[:, t].unsqueeze(-2)
        outs.append((q[:, t].unsqueeze(-1) * S).sum(dim=-2))
    Z = torch.stack(outs, dim=1)
    w = F.softmax(mem.beta, dim=0)
    lin = torch.einsum('n,btnd->btd', w, Z)
    zs = Z.sum(dim=2)
    inter = mem.gamma * ((zs ** 2) - (Z ** 2).sum(dim=2)) / 2
    comp = mem.zeta * Z.max(dim=2)[0]
    return mem.out(lin + inter + comp)


def test_chunkwise_matches_sequential():
    for T in [7, 32, 50, 96]:
        mem = BranchMemory(d=32, n_branch=2, dk=8, dv=8, chunk=16)
        x = torch.randn(3, T, 32)
        out_fast = mem(x)
        out_ref = naive_reference(mem, x)
        err = (out_fast - out_ref).abs().max().item()
        assert err < 1e-4, f"T={T}: max err {err}"
        print(f"  T={T}: chunkwise == sequential (max err {err:.2e})  OK")


def test_causality():
    """Output at position t must not depend on tokens > t."""
    mem = BranchMemory(d=32, n_branch=2, dk=8, dv=8, chunk=16)
    x = torch.randn(1, 40, 32)
    out1 = mem(x)
    x2 = x.clone()
    x2[:, 30:] = torch.randn_like(x2[:, 30:])  # perturb the future
    out2 = mem(x2)
    diff = (out1[:, :30] - out2[:, :30]).abs().max().item()
    assert diff < 1e-5, f"causality violated: {diff}"
    print(f"  causality preserved (past diff {diff:.2e})  OK")


def test_models_forward_backward():
    for Model, kw in [(BranchCellV2, dict(vocab=100, n_classes=3)),
                      (DecoderTransformer, dict(vocab=100, n_classes=3, max_len=64))]:
        m = Model(**kw)
        x = torch.randint(1, 100, (4, 33))
        x[0, 20:] = 0  # padding
        y = torch.randint(0, 3, (4,))
        loss = torch.nn.functional.cross_entropy(m(x), y)
        loss.backward()
        n = sum(p.numel() for p in m.parameters())
        print(f"  {Model.__name__}: fwd+bwd OK, params={n:,}")


if __name__ == '__main__':
    print("test_chunkwise_matches_sequential:")
    test_chunkwise_matches_sequential()
    print("test_causality:")
    test_causality()
    print("test_models_forward_backward:")
    test_models_forward_backward()
    print("\nALL TESTS PASSED")
