"""Correctness tests for BranchCell v3 (hard-routed branch memory)."""
import torch
from branchcell_v3 import HardRoutedBranchMemory, BranchCellV3


def test_causality():
    """Output at position t must not depend on tokens > t."""
    torch.manual_seed(0)
    mem = HardRoutedBranchMemory(d=32, n_branch=6, top_k=2, dk=8, dv=8, conv_k=3)
    mem.eval()
    x = torch.randn(2, 40, 32)
    out1, _ = mem(x)
    x2 = x.clone()
    x2[:, 30:] = torch.randn_like(x2[:, 30:])      # perturb the future
    out2, _ = mem(x2)
    diff = (out1[:, :30] - out2[:, :30]).abs().max().item()
    assert diff < 1e-5, f"causality violated: {diff}"
    print(f"  causality preserved (past diff {diff:.2e})  OK")


def test_routing_is_hard():
    """Exactly top_k branches active per token; weights sum to 1."""
    torch.manual_seed(1)
    mem = HardRoutedBranchMemory(d=32, n_branch=8, top_k=2, dk=8, dv=8)
    x = torch.randn(4, 20, 32)
    r, aux = mem._route(x)
    nnz = (r > 0).sum(-1)
    assert (nnz == 2).all(), f"expected exactly 2 active branches, got {nnz.unique()}"
    sums = r.sum(-1)
    assert torch.allclose(sums, torch.ones_like(sums), atol=1e-5), "weights must sum to 1"
    assert aux.item() > 0, "aux load-balance loss must be positive"
    print(f"  hard top-2 routing verified (aux={aux.item():.3f})  OK")


def test_gradients():
    """All parameters (incl. router) must receive gradients."""
    torch.manual_seed(2)
    model = BranchCellV3(vocab=50, d=32, n_layers=2, n_branch=6, top_k=2,
                         dk=8, dv=8, n_classes=3)
    x = torch.randint(1, 50, (4, 25))
    y = torch.randint(0, 3, (4,))
    logits, aux = model(x, return_aux=True)
    loss = torch.nn.functional.cross_entropy(logits, y) + aux
    loss.backward()
    missing = [n for n, p in model.named_parameters()
               if p.requires_grad and (p.grad is None or p.grad.abs().sum() == 0)]
    assert not missing, f"params with no gradient: {missing[:5]}"
    print(f"  all {sum(1 for _ in model.parameters())} param tensors got gradients  OK")


def test_specialization_capacity():
    """More branches with fixed top_k => more capacity, same per-token write cost."""
    m1 = HardRoutedBranchMemory(d=32, n_branch=4, top_k=2, dk=8, dv=8)
    m2 = HardRoutedBranchMemory(d=32, n_branch=16, top_k=2, dk=8, dv=8)
    p1 = sum(p.numel() for p in m1.parameters())
    p2 = sum(p.numel() for p in m2.parameters())
    assert p2 > p1, "more branches should add parameters (capacity)"
    print(f"  capacity scales with branches (4br={p1} < 16br={p2} params)  OK")


if __name__ == "__main__":
    print("Running BranchCell v3 correctness tests...\n")
    test_causality()
    test_routing_is_hard()
    test_gradients()
    test_specialization_capacity()
    print("\nAll v3 tests passed.")
