"""Correctness tests for BranchCell v4 (multi-scale + RoPE + local attention)."""
import torch
from branchcell_v4 import (
    MultiScaleHardRoutedBranchMemory, BranchCellV4,
    apply_rope, RMSNorm
)


def test_causality():
    """Output at position t must not depend on tokens > t."""
    torch.manual_seed(0)
    mem = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=6, top_k=2, dk=8, dv=8, conv_k=3,
        n_scales=3, local_win=8)
    mem.eval()
    x = torch.randn(2, 40, 32)
    out1, _ = mem(x)
    x2 = x.clone()
    x2[:, 30:] = torch.randn_like(x2[:, 30:])
    out2, _ = mem(x2)
    diff = (out1[:, :30] - out2[:, :30]).abs().max().item()
    assert diff < 1e-5, f"causality violated: {diff}"
    print(f"  causality preserved (past diff {diff:.2e})  OK")


def test_routing_is_hard():
    """Exactly top_k branches active per token; weights sum to 1."""
    torch.manual_seed(1)
    mem = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=8, top_k=2, dk=8, dv=8, n_scales=3)
    x = torch.randn(4, 20, 32)
    r, aux = mem._route(x)
    nnz = (r > 0).sum(-1)
    assert (nnz == 2).all(), f"expected exactly 2 active branches, got {nnz.unique()}"
    sums = r.sum(-1)
    assert torch.allclose(sums, torch.ones_like(sums), atol=1e-5), "weights must sum to 1"
    assert aux.item() > 0, "aux load-balance loss must be positive"
    print(f"  hard top-2 routing verified (aux={aux.item():.3f})  OK")


def test_rope_preserves_norm():
    """RoPE should preserve vector norm (rotation)."""
    torch.manual_seed(2)
    B, T, nb, dk = 2, 10, 4, 16
    qk = torch.randn(B, T, nb, dk)
    positions = torch.arange(T, dtype=torch.float32)
    out = apply_rope(qk, positions)
    
    # norms should be preserved (rotation)
    in_norm = qk.norm(dim=-1)
    out_norm = out.norm(dim=-1)
    assert torch.allclose(in_norm, out_norm, atol=1e-5), "RoPE must preserve norms"
    
    # different positions -> different outputs
    qk_same = torch.randn(1, 2, 4, 16)
    pos0 = torch.tensor([0., 1.])
    pos1 = torch.tensor([5., 6.])
    out0 = apply_rope(qk_same, pos0)
    out1 = apply_rope(qk_same, pos1)
    assert not torch.allclose(out0, out1, atol=1e-3), "RoPE must differentiate positions"
    print("  RoPE preserves norms and differentiates positions  OK")


def test_multi_scale_different_decays():
    """Different scales should have different effective memory lengths."""
    torch.manual_seed(3)
    mem = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=4, top_k=2, dk=8, dv=8,
        n_scales=3, local_win=0)  # disable local attn for pure scale test
    mem.eval()
    
    # Check that gate biases are different
    biases = [wg.bias.mean().item() for wg in mem.Wg]
    assert len(set(round(b, 1) for b in biases)) >= 2, \
        f"scales should have different biases, got {biases}"
    
    # Forward should work
    x = torch.randn(2, 20, 32)
    out, aux = mem(x)
    assert out.shape == x.shape
    print(f"  multi-scale with different decays {biases} works  OK")


def test_local_attention_causal():
    """Local sliding attention must be causal."""
    torch.manual_seed(4)
    mem = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=4, top_k=2, dk=8, dv=8,
        n_scales=2, local_win=8)
    mem.eval()
    
    x = torch.randn(2, 40, 32)
    out1, _ = mem(x)
    x2 = x.clone()
    x2[:, 25:] = torch.randn_like(x2[:, 25:])
    out2, _ = mem(x2)
    
    # Position 20 should not see position 25+
    diff = (out1[:, :20] - out2[:, :20]).abs().max().item()
    assert diff < 1e-5, f"local attention violated causality: {diff}"
    print(f"  local sliding attention is causal (diff {diff:.2e})  OK")


def test_gradients():
    """All parameters must receive gradients."""
    torch.manual_seed(5)
    model = BranchCellV4(
        vocab=50, d=32, n_layers=2, n_branch=6, top_k=2,
        dk=8, dv=8, n_classes=3, n_scales=3, local_win=8)
    x = torch.randint(1, 50, (4, 25))
    y = torch.randint(0, 3, (4,))
    logits, aux = model(x, return_aux=True)
    loss = torch.nn.functional.cross_entropy(logits, y) + aux
    loss.backward()
    missing = [n for n, p in model.named_parameters()
               if p.requires_grad and (p.grad is None or p.grad.abs().sum() == 0)]
    assert not missing, f"params with no gradient: {missing[:5]}"
    n_params = sum(1 for _ in model.parameters())
    print(f"  all {n_params} param tensors got gradients  OK")


def test_adaptive_fusion():
    """Adaptive fusion gate should output values in (0,1)."""
    torch.manual_seed(6)
    mem = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=4, top_k=2, dk=8, dv=8,
        n_scales=2, local_win=8)
    mem.eval()
    
    x = torch.randn(4, 16, 32)
    # Manually compute fusion gate output
    with torch.no_grad():
        xl = x  # skip conv for simplicity
        # Compute dummy branch and local outputs
        out_branch = torch.randn(4, 16, 32)
        out_local = torch.randn(4, 16, 32)
        fusion_input = torch.cat([out_branch, out_local], dim=-1)
        gate = torch.sigmoid(mem.fusion_gate(fusion_input))
        assert (gate >= 0).all() and (gate <= 1).all(), "fusion gate must be in [0,1]"
    print(f"  adaptive fusion gate in [0,1] (mean={gate.mean():.3f})  OK")


def test_capacity_scales():
    """More scales and branches = more capacity."""
    m1 = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=4, top_k=2, dk=8, dv=8, n_scales=1)
    m2 = MultiScaleHardRoutedBranchMemory(
        d=32, n_branch=8, top_k=2, dk=8, dv=8, n_scales=3)
    p1 = sum(p.numel() for p in m1.parameters())
    p2 = sum(p.numel() for p in m2.parameters())
    assert p2 > p1, "more scales+branches should add parameters"
    print(f"  capacity scales (1-scale,4br={p1} < 3-scale,8br={p2})  OK")


def test_full_model_shapes():
    """Full BranchCellV4 forward pass with correct output shapes."""
    torch.manual_seed(7)
    model = BranchCellV4(
        vocab=100, d=64, n_layers=2, n_branch=4, top_k=2,
        dk=16, dv=16, n_classes=5, n_scales=3, local_win=16)
    model.eval()
    
    # Test various sequence lengths
    for T in [8, 32, 64]:
        x = torch.randint(1, 100, (4, T))
        logits = model(x)
        assert logits.shape == (4, 5), f"expected (4,5), got {logits.shape} for T={T}"
    print("  full model output shapes correct for T=8,32,64  OK")


if __name__ == "__main__":
    print("Running BranchCell v4 correctness tests...\n")
    test_causality()
    test_routing_is_hard()
    test_rope_preserves_norm()
    test_multi_scale_different_decays()
    test_local_attention_causal()
    test_gradients()
    test_adaptive_fusion()
    test_capacity_scales()
    test_full_model_shapes()
    print("\nAll v4 tests passed.")
