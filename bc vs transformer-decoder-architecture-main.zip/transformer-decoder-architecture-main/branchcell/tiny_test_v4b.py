import torch, torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import random, numpy as np
from branchcell_v4b import BranchCellV4, DecoderTransformer

random.seed(42); np.random.seed(42); torch.manual_seed(42)

class Tok:
    def __init__(self):
        self.w2i = {'<pad>': 0, '<unk>': 1}
    def build(self, texts):
        for t in texts:
            for w in t.split():
                if w not in self.w2i:
                    self.w2i[w] = len(self.w2i)
    @property
    def vocab(self):
        return len(self.w2i)
    def enc(self, t, L):
        ids = [self.w2i.get(w, 1) for w in t.split()][:L]
        return ids + [0] * (L - len(ids))

class DS(Dataset):
    def __init__(self, texts, labels, tok, L):
        self.x = [tok.enc(t, L) for t in texts]
        self.y = labels
    def __len__(self):
        return len(self.y)
    def __getitem__(self, i):
        return torch.tensor(self.x[i]), torch.tensor(self.y[i])

NAMES = ['anna', 'ben', 'carl', 'dora', 'evan', 'fay', 'gus', 'hana']

def gen_multihop(n, hops=3):
    texts, labels = [], []
    for _ in range(n):
        names = random.sample(NAMES, len(NAMES))
        chain = names[:hops + 1]
        facts = [f'{chain[i]} points to {chain[i+1]} .' for i in range(hops)]
        facts += [f'{names[hops+1]} points to {random.choice(NAMES)} .']
        random.shuffle(facts)
        cands = [chain[-1]] + random.sample([x for x in NAMES if x != chain[-1]], 3)
        random.shuffle(cands)
        lab = cands.index(chain[-1])
        opts = 'options : ' + ' '.join(f'{i} {c}' for i, c in enumerate(cands))
        texts.append(' '.join(facts) + f' question : where does {chain[0]} finally arrive ? ' + opts)
        labels.append(lab)
    return texts, labels, 4

def gen_needle(n, ctx_words=64):
    KEYS = ['sunshine', 'galaxy', 'horizon', 'mountain', 'river']
    FILLER = ['the weather was pleasant .', 'many people attended .', 'coffee was served .', 'the discussion lasted .', 'documents were reviewed .']
    texts, labels = [], []
    for _ in range(n):
        key = random.randrange(len(KEYS))
        fact = f'remember this : the secret code is {KEYS[key]} .'
        sents = []
        while sum(len(s.split()) for s in sents) < ctx_words - 10:
            sents.append(random.choice(FILLER))
        sents.insert(random.randint(0, len(sents)), fact)
        texts.append(' '.join(sents) + ' question : what is the secret code ?')
        labels.append(key)
    return texts, labels, len(KEYS)

def run(model, trl, tel, epochs, is_branch):
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3, weight_decay=0.01)
    for _ in range(epochs):
        model.train()
        for xb, yb in trl:
            opt.zero_grad()
            if is_branch:
                logits, aux = model(xb, return_aux=True)
                loss = F.cross_entropy(logits, yb) + aux
            else:
                loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
    model.eval()
    correct = tot = 0
    with torch.no_grad():
        for xb, yb in tel:
            pred = model(xb).argmax(-1)
            correct += (pred == yb).sum().item(); tot += yb.numel()
    return correct / tot

print("=" * 55)
print("v4b TINY TEST: 100 samples, small models, 4-6 epochs")
print("=" * 55)

# MultiHop
random.seed(42); torch.manual_seed(42)
texts, labels, ncls = gen_multihop(100, hops=3)
tok = Tok(); tok.build(texts)
idx = list(range(len(texts))); random.shuffle(idx)
cut = int(0.8 * len(texts))
trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, 48), batch_size=16, shuffle=True)
tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, 48), batch_size=32)

bc = BranchCellV4(tok.vocab, d=48, n_layers=2, n_branch=4, top_k=2, dk=12, dv=12, n_classes=ncls, n_scales=3, local_win=16)
tr = DecoderTransformer(tok.vocab, d=48, n_layers=2, n_heads=4, n_classes=ncls, max_len=128)

bc_acc = run(bc, trl, tel, 4, True)
tr_acc = run(tr, trl, tel, 4, False)
print(f"\n[MultiHop] BC={bc_acc:.3f} TR={tr_acc:.3f} -> {'BC' if bc_acc > tr_acc else 'TR'} (d={bc_acc-tr_acc:+.3f})")

# Needle64
random.seed(42); torch.manual_seed(42)
texts, labels, ncls = gen_needle(80, ctx_words=64)
tok = Tok(); tok.build(texts)
idx = list(range(len(texts))); random.shuffle(idx)
cut = int(0.8 * len(texts))
trl = DataLoader(DS([texts[i] for i in idx[:cut]], [labels[i] for i in idx[:cut]], tok, 80), batch_size=12, shuffle=True)
tel = DataLoader(DS([texts[i] for i in idx[cut:]], [labels[i] for i in idx[cut:]], tok, 80), batch_size=24)

bc = BranchCellV4(tok.vocab, d=48, n_layers=2, n_branch=4, top_k=2, dk=12, dv=12, n_classes=ncls, n_scales=3, local_win=16)
tr = DecoderTransformer(tok.vocab, d=48, n_layers=2, n_heads=4, n_classes=ncls, max_len=256)

bc_acc = run(bc, trl, tel, 6, True)
tr_acc = run(tr, trl, tel, 6, False)
print(f"[Needle64] BC={bc_acc:.3f} TR={tr_acc:.3f} -> {'BC' if bc_acc > tr_acc else 'TR'} (d={bc_acc-tr_acc:+.3f})")
print("\nDone!")
